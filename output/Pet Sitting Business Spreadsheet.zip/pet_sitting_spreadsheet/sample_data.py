"""
Example records for the registers.

When sample data is switched on (the default) every register is filled with a
small, realistic set of records so the dashboard, reports, reminders and
printables show real numbers the moment the workbook is opened.  The records
are dated relative to the build date (``Config.today``) and use the names
defined on the Settings, Services and Staff tabs so every lookup joins up.

Turn it off with ``--blank`` or ``Config(include_sample_data=False)``.
"""

from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass, field
from typing import Any, Dict, List

from .config import Config


def _day(base: _dt.date, offset: int) -> _dt.date:
    return base + _dt.timedelta(days=offset)


@dataclass
class Sample:
    services: List[Dict[str, Any]] = field(default_factory=list)
    clients: List[Dict[str, Any]] = field(default_factory=list)
    pets: List[Dict[str, Any]] = field(default_factory=list)
    staff: List[Dict[str, Any]] = field(default_factory=list)
    bookings: List[Dict[str, Any]] = field(default_factory=list)
    visits: List[Dict[str, Any]] = field(default_factory=list)
    invoices: List[Dict[str, Any]] = field(default_factory=list)
    payments: List[Dict[str, Any]] = field(default_factory=list)
    expenses: List[Dict[str, Any]] = field(default_factory=list)
    mileage: List[Dict[str, Any]] = field(default_factory=list)
    health: List[Dict[str, Any]] = field(default_factory=list)
    incidents: List[Dict[str, Any]] = field(default_factory=list)
    messages: List[Dict[str, Any]] = field(default_factory=list)
    inventory: List[Dict[str, Any]] = field(default_factory=list)
    reminders: List[Dict[str, Any]] = field(default_factory=list)
    budget: List[Dict[str, Any]] = field(default_factory=list)


_CACHE: Dict[int, Sample] = {}


def get(cfg: Config) -> Sample:
    """Build (once per configuration) the example dataset."""
    key = id(cfg)
    if key not in _CACHE:
        _CACHE[key] = _build(cfg)
    return _CACHE[key]


# ---------------------------------------------------------------------------

#: service name -> (category, unit, minutes, rate, extra pet fee, staff cost,
#:                  travel?, holiday %, weekend %)
SERVICES = {
    "Dog Walk - 30 min": ("Dog walking", "Per walk", 30, 25, 8, 11, "No",
                          None, None),
    "Dog Walk - 60 min": ("Dog walking", "Per walk", 60, 40, 12, 20, "No",
                          None, None),
    "Drop-in Visit": ("Drop-in visit", "Per visit", 30, 26, 8, 11, "No",
                      None, None),
    "Cat Feeding Visit": ("Feeding visit", "Per visit", 20, 22, 6, 9, "No",
                          None, None),
    "Overnight Pet Sitting": ("Overnight stay", "Per night", 840, 95, 20,
                              45, "Yes", None, None),
    "Pet Taxi Transfer": ("Pet transport", "Per hour", 60, 38, 10, 17, "Yes",
                          0.35, None),
}

#: booking offsets (days from today), one booking per day so the schedule
#: never double books a carer.  (offset, client, pet, service, start hour,
#: staff, status)
BOOKING_PLAN = [
    (-18, "Sarah Mitchell", "Bella", "Dog Walk - 60 min", 10,
     "Jamie Lee", "Completed"),
    (-16, "Priya Raman", "Cooper", "Dog Walk - 30 min", 9,
     "Jamie Lee", "Completed"),
    (-15, "Megan Foster", "Milo", "Cat Feeding Visit", 8,
     "Priya Shah", "Completed"),
    (-13, "Daniel Brooks", "Daisy", "Dog Walk - 60 min", 7,
     "Alex Morgan", "Completed"),
    (-12, "James Okafor", "Luna", "Overnight Pet Sitting", 19,
     "Priya Shah", "Completed"),
    (-10, "Luis Hernandez", "Ruby", "Dog Walk - 30 min", 15,
     "Alex Morgan", "Completed"),
    (-9, "Chloe Bennett", "Oscar", "Drop-in Visit", 12,
     "Priya Shah", "Cancelled"),
    (-7, "Sarah Mitchell", "Max", "Dog Walk - 30 min", 11,
     "Jamie Lee", "Completed"),
    (-5, "Megan Foster", "Simba", "Cat Feeding Visit", 8,
     "Priya Shah", "Completed"),
    (-4, "Daniel Brooks", "Teddy", "Drop-in Visit", 13,
     "Alex Morgan", "Completed"),
    (-2, "James Okafor", "Luna", "Drop-in Visit", 17,
     "Priya Shah", "Completed"),
    (-1, "Chloe Bennett", "Poppy", "Drop-in Visit", 16,
     "Priya Shah", "Completed"),
    (0, "Sarah Mitchell", "Bella", "Dog Walk - 60 min", 10,
     "Jamie Lee", "Confirmed"),
    (1, "Priya Raman", "Cooper", "Dog Walk - 30 min", 9,
     "Jamie Lee", "Confirmed"),
    (2, "Megan Foster", "Milo", "Cat Feeding Visit", 8,
     "Priya Shah", "Confirmed"),
    (4, "Luis Hernandez", "Ruby", "Dog Walk - 30 min", 15,
     "Alex Morgan", "Confirmed"),
    (6, "James Okafor", "Luna", "Overnight Pet Sitting", 19,
     "Priya Shah", "Pending"),
    (9, "Daniel Brooks", "Daisy", "Pet Taxi Transfer", 14,
     "Alex Morgan", "Pending"),
    (12, "Chloe Bennett", "Oscar", "Drop-in Visit", 12,
     "Priya Shah", "Pending"),
]

#: pet name -> owner, species, breed, age in days (negative), gender,
#: weight, colour, temperament, risk, handling note, vaccination expiry offset
PETS = [
    ("Bella", "Sarah Mitchell", "Dog", "Labrador Retriever", -1460,
     "Female (spayed)", 28.5, "Golden", "Friendly", "Pulls on lead",
     "Harness on before the front door opens", 160),
    ("Max", "Sarah Mitchell", "Dog", "Beagle", -980, "Male (neutered)",
     14.2, "Tricolour", "Energetic", "Escape artist",
     "Check the side gate latch before leaving", 40),
    ("Luna", "James Okafor", "Cat", "Ragdoll", -1100, "Female (spayed)",
     4.8, "Cream point", "Shy", "None",
     "Let her come to you - never lift her", 200),
    ("Cooper", "Priya Raman", "Dog", "Cockapoo", -620, "Male (neutered)",
     9.4, "Apricot", "Playful", "Jumps up",
     "Lead on in the hallway, treats for calm", 25),
    ("Daisy", "Daniel Brooks", "Dog", "Border Collie", -1750, "Female",
     19.0, "Black and white", "Energetic", "None",
     "Long line until recall is solid", -12),
    ("Milo", "Megan Foster", "Cat", "Domestic Short Hair", -2200,
     "Male (neutered)", 5.6, "Black and white", "Calm", "Medical risk",
     "Give medication before food - watch appetite", 90),
    ("Ruby", "Luis Hernandez", "Dog", "Staffordshire Bull Terrier", -1330,
     "Female (spayed)", 16.8, "Brindle", "Reactive", "Not dog friendly",
     "Keep 10 m from other dogs - treat scatter to pass", 95),
    ("Oscar", "Chloe Bennett", "Dog", "Dachshund", -700, "Male (neutered)",
     7.2, "Black and tan", "Friendly", "None",
     "Lift with two hands supporting the back", 300),
    ("Poppy", "Chloe Bennett", "Rabbit", "Mini Lop", -500, "Female", 1.9,
     "White", "Shy", "None", "Support the back legs when lifting", 20),
    ("Simba", "Megan Foster", "Cat", "Maine Coon", -900, "Male", 7.9,
     "Ginger tabby", "Playful", "Escape artist",
     "Shut the hallway door before opening the front door", 35),
    ("Teddy", "Daniel Brooks", "Dog", "Cavoodle", -300, "Male (neutered)",
     8.1, "Chocolate", "Friendly", "None",
     "Leave the radio on - he whines when alone", 180),
    ("Charlie", "Robert Nguyen", "Dog", "Golden Retriever", -2500,
     "Male (neutered)", 32.0, "Golden", "Calm", "None",
     "Help him into the car with the ramp", -120),
]

STAFF = [
    dict(name="Alex Morgan", role="Owner", phone="+1 (555) 014 2200",
         email="alex@happypawspetcare.com", employment="Employee - full time",
         start=-980, status="Active", pay_type="Salary", pay_rate=26,
         cert="Pet First Aid, Canine Behaviour L3", cert_expiry=160,
         availability="Mon-Fri 07:00-18:00", notes="Handles reactive dogs"),
    dict(name="Jamie Lee", role="Dog walker", phone="+1 (555) 330 8812",
         email="jamie@happypawspetcare.com",
         employment="Employee - part time", start=-420, status="Active",
         pay_type="Hourly", pay_rate=19, cert="Pet First Aid",
         cert_expiry=24, availability="Mon-Sat 08:00-16:00",
         notes="Great with puppies"),
    dict(name="Priya Shah", role="Pet sitter", phone="+1 (555) 772 6690",
         email="priya@happypawspetcare.com", employment="Casual",
         start=-260, status="Active", pay_type="Per visit", pay_rate=16,
         cert="Pet First Aid, Cat Care", cert_expiry=310,
         availability="Tue-Sun 09:00-20:00", notes="Overnight specialist"),
    dict(name="Tom Reed", role="Contractor", phone="+1 (555) 448 1120",
         email="tom.reed@example.com", employment="Contractor",
         start=-120, status="Active", pay_type="Per visit", pay_rate=18,
         cert="Pet First Aid", cert_expiry=-8, availability="Weekends only",
         notes="Certificate expired - chase renewal"),
]

CLIENTS = [
    dict(name="Sarah Mitchell", phone="+1 (555) 201 7744",
         email="sarah.mitchell@example.com", address="14 Juniper Way",
         city="Springfield", postcode="62704", emergency_name="Tom Mitchell",
         emergency_phone="+1 (555) 201 7745", contact_method="SMS",
         referral="Google search", reg=-240, status="Active",
         key_status="Key held", key_tag="KEY-01", key_returned=None,
         access_notes="Lockbox by side gate - code held in password manager",
         access_code="Hint: birthday month", contract="Signed",
         agreement=-238, vet_consent="Yes", vet_limit=500,
         preferences="Bella pulls left on the lead. Treats in the blue tin.",
         notes="Prefers evening walks. Pays by card on the 1st."),
    dict(name="James Okafor", phone="+1 (555) 889 2031",
         email="james.okafor@example.com", address="7 Ashgrove Court",
         city="Springfield", postcode="62702", emergency_name="Ada Okafor",
         emergency_phone="+1 (555) 889 2032", contact_method="Email",
         referral="Client referral", reg=-190, status="Active",
         key_status="Key held", key_tag="KEY-02", key_returned=None,
         access_notes="Front door key. Alarm - ring owner first.",
         access_code="Hint: street number + 1", contract="Signed",
         agreement=-188, vet_consent="Yes", vet_limit=400,
         preferences="Luna hides under the bed - give her 10 minutes.",
         notes="Travels for work most months."),
    dict(name="Priya Raman", phone="+1 (555) 663 4417",
         email="priya.raman@example.com", address="92 Hilltop Drive",
         city="Riverton", postcode="62711", emergency_name="Vijay Raman",
         emergency_phone="+1 (555) 663 4418", contact_method="WhatsApp",
         referral="Instagram", reg=-150, status="Active",
         key_status="Lockbox code", key_tag="-", key_returned=None,
         access_notes="Lockbox on the tap - code sent by text.",
         access_code="Hint: see text", contract="Signed", agreement=-148,
         vet_consent="Yes", vet_limit=600,
         preferences="Cooper is in training - no treats before walks.",
         notes="Weekly Tuesday and Thursday walks."),
    dict(name="Daniel Brooks", phone="+1 (555) 712 9034",
         email="daniel.brooks@example.com", address="3 Meadow Lane",
         city="Springfield", postcode="62703", emergency_name="Erin Brooks",
         emergency_phone="+1 (555) 712 9035", contact_method="Phone call",
         referral="Vet clinic", reg=-120, status="Active",
         key_status="Key held", key_tag="KEY-04", key_returned=None,
         access_notes="Back door - lift the handle then turn.",
         access_code="Hint: none", contract="Signed", agreement=-118,
         vet_consent="Yes", vet_limit=750,
         preferences="Daisy needs 60 minute runs. Teddy stays home.",
         notes="Referred by Riverton Vet Clinic."),
    dict(name="Megan Foster", phone="+1 (555) 204 5588",
         email="megan.foster@example.com", address="18 Willow Street",
         city="Riverton", postcode="62712", emergency_name="Chris Foster",
         emergency_phone="+1 (555) 204 5589", contact_method="SMS",
         referral="Facebook", reg=-95, status="Active",
         key_status="Smart lock code", key_tag="-",
         key_returned=None,
         access_notes="Smart lock - code sent when booking is confirmed.",
         access_code="Hint: see booking", contract="Signed", agreement=-93,
         vet_consent="Yes", vet_limit=350,
         preferences="Two cats - feed separately. Milo is on medication.",
         notes="Books two weeks of holiday cover twice a year."),
    dict(name="Luis Hernandez", phone="+1 (555) 556 1177",
         email="luis.hernandez@example.com", address="45 Oakfield Road",
         city="Springfield", postcode="62705", emergency_name="Maria Hernandez",
         emergency_phone="+1 (555) 556 1178", contact_method="Phone call",
         referral="Word of mouth", reg=-70, status="Active",
         key_status="Not held", key_tag="-", key_returned=None,
         access_notes="Owner home most days - ring the bell.",
         access_code="Hint: none", contract="Sent", agreement=None,
         vet_consent="No", vet_limit=300,
         preferences="Ruby is nervous with men in hats.",
         notes="Pays cash at the end of each week."),
    dict(name="Chloe Bennett", phone="+1 (555) 991 3320",
         email="chloe.bennett@example.com", address="11 Garden Terrace",
         city="Riverton", postcode="62713", emergency_name="Paul Bennett",
         emergency_phone="+1 (555) 991 3321", contact_method="Email",
         referral="Flyer / poster", reg=-45, status="Active",
         key_status="Key held", key_tag="KEY-05", key_returned=None,
         access_notes="Side gate latch - key under the planter.",
         access_code="Hint: none", contract="Sent", agreement=None,
         vet_consent="Yes", vet_limit=250,
         preferences="Poppy the rabbit needs fresh greens daily.",
         notes="Send the six week check-in."),
    dict(name="Robert Nguyen", phone="+1 (555) 338 7742",
         email="robert.nguyen@example.com", address="60 Station Road",
         city="Springfield", postcode="62701", emergency_name="Linh Nguyen",
         emergency_phone="+1 (555) 338 7743", contact_method="SMS",
         referral="Google search", reg=-400, status="Inactive",
         key_status="Key returned", key_tag="-", key_returned=-300,
         access_notes="Key returned 10 months ago.",
         access_code="-", contract="Expired", agreement=-400,
         vet_consent="No", vet_limit=0,
         preferences="Charlie loves the river path.",
         notes="Moved away - win-back candidate."),
    dict(name="Amelia Clarke", phone="+1 (555) 447 2218",
         email="amelia.clarke@example.com", address="2 Bridge View",
         city="Riverton", postcode="62714", emergency_name="Noah Clarke",
         emergency_phone="+1 (555) 447 2219", contact_method="Email",
         referral="Instagram", reg=-12, status="Prospective",
         key_status="Not held", key_tag="-", key_returned=None,
         access_notes="Meet and greet booked.", access_code="-",
         contract="Not sent", agreement=None, vet_consent="No",
         vet_limit=0, preferences="Two rescue dogs - slow introduction.",
         notes="Quote sent for weekday walks."),
]

MILEAGE_PLAN = [
    (-28, "Alex Morgan", "Sarah Mitchell", "Client visit", 48200, 48219),
    (-26, "Jamie Lee", "Priya Raman", "Client visit", 51840, 51862),
    (-24, "Priya Shah", "James Okafor", "Overnight stay", 40310, 40338),
    (-21, "Jamie Lee", "Luis Hernandez", "Dog walk", 51862, 51880),
    (-17, "Alex Morgan", "Daniel Brooks", "Client visit", 48219, 48241),
    (-14, "Priya Shah", "Megan Foster", "Client visit", 40338, 40351),
    (-9, "Alex Morgan", "Daniel Brooks", "Vet trip", 48241, 48262),
    (-4, "Jamie Lee", "Sarah Mitchell", "Supplies run", 51880, 51897),
]

EXPENSES = [
    (-29, "Fuel", "Weekly fuel - client visits", "QuickFuel", 62.40,
     "Card - online", "Business", 1.0, "No", "Yes", "Approved"),
    (-27, "Pet supplies", "Poop bags, wipes and treats", "PetMart", 48.75,
     "Card - in person", "Business", 1.0, "No", "Yes", "Approved"),
    (-25, "Software & subscriptions", "Scheduling app - monthly", "PetDesk",
     29.00, "Direct debit", "Business", 1.0, "Monthly", "Yes", "Approved"),
    (-24, "Marketing & advertising", "Local social media ads", "Meta",
     45.00, "Card - online", "Business", 1.0, "No", "Yes", "Approved"),
    (-22, "Insurance", "Business liability - monthly", "PetGuard Business",
     48.00, "Direct debit", "Business", 1.0, "Monthly", "Yes", "Approved"),
    (-18, "Equipment", "Two slip leads and a treat pouch", "PetMart", 39.90,
     "Card - in person", "Business", 1.0, "No", "Yes", "Approved"),
    (-16, "Fuel", "Weekly fuel - client visits", "QuickFuel", 58.20,
     "Card - online", "Business", 1.0, "No", "Yes", "Approved"),
    (-14, "Vehicle maintenance", "Tyre rotation and oil change", "AutoFix",
     86.00, "Bank transfer", "Business", 1.0, "No", "Yes", "Approved"),
    (-12, "Staff wages", "Jamie Lee - fortnight", "Payroll", 396.00,
     "Bank transfer", "Business", 1.0, "Fortnightly", "Yes", "Approved"),
    (-8, "Training & certification", "Canine first aid refresher",
     "PetCare Academy", 65.00, "Card - online", "Business", 1.0, "No",
     "Yes", "Approved"),
    (-7, "Phone & internet", "Broadband - part business use", "TelCo",
     55.00, "Direct debit", "Business", 0.6, "Monthly", "Yes", "Approved"),
    (-5, "Pet supplies", "Toys for my own dog", "PetMart", 32.00,
     "Card - in person", "Personal", 0.0, "No", "No", "Approved"),
    (-3, "Contractor payments", "Tom Reed - weekend walks", "Tom Reed",
     145.00, "Bank transfer", "Business", 1.0, "No", "Yes", "Pending"),
    (-2, "Vet & emergency supplies", "First aid kit restock",
     "Riverton Vet Clinic", 42.30, "Card - in person", "Business", 1.0,
     "No", "Yes", "Approved"),
    (0, "Bank & merchant fees", "Card processing fees", "PayGate", 18.45,
     "Direct debit", "Business", 1.0, "Monthly", "No", "Pending"),
]

HEALTH = [
    (-9, "Milo", "Medication", "Felimazole 2.5mg", "1 tablet in food",
     "07:00", "07:10", "Priya Shah", "Given", 18, 12, 0, "Yes",
     "Ate the full portion"),
    (-5, "Milo", "Medication", "Felimazole 2.5mg", "1 tablet in food",
     "07:00", "07:05", "Priya Shah", "Given", 16, 12, 0, "Yes", ""),
    (-2, "Milo", "Medication", "Felimazole 2.5mg", "1 tablet in food",
     "07:00", None, "Priya Shah", "Missed", 16, 12, 0, "Yes",
     "Refused food - owner called, giving it tonight"),
    (-20, "Charlie", "Vet visit", "Arthritis review", "Metacam 0.8ml daily",
     "10:30", None, "Alex Morgan", "Not required", None, None, 110.0,
     "Yes", "Owner attended - we transported"),
    (-15, "Bella", "Vaccination", "Annual booster", "-", "09:00", None,
     "Alex Morgan", "Not required", None, None, 86.0, "Yes",
     "Certificate photographed"),
    (-1, "Teddy", "Health observation", "Loose stool", "-", "13:20", None,
     "Alex Morgan", "Not required", None, None, 0, "Yes",
     "Owner changing food gradually"),
    (3, "Milo", "Medication", "Felimazole 2.5mg", "1 tablet in food",
     "07:00", None, "Priya Shah", "Scheduled", 14, 12, 0, "No", ""),
]

INCIDENTS = [
    (-22, "10:40", "Luis Hernandez", "Ruby (Luis Hernandez)", "Alex Morgan",
     "Aggression", "Medium",
     "Ruby lunged at an off-lead dog on Oakfield Road",
     "Moved to a side street, treat scatter, finished on quiet streets",
     "No", "Yes", -15, "Resolved", 0, "No"),
    (-11, "16:15", "Chloe Bennett", "Oscar (Chloe Bennett)", "Priya Shah",
     "Injury", "Low", "Small cut on the left front paw from a stick",
     "Cleaned with saline and covered - photo sent to owner", "No", "Yes",
     -4, "Resolved", 0, "No"),
    (-3, "08:20", "Megan Foster", "Simba (Megan Foster)", "Priya Shah",
     "Escape", "High",
     "Simba dashed into the hallway when the front door opened",
     "Door closed immediately - Simba recovered within 2 minutes", "No",
     "Yes", 4, "In progress", 0, "No"),
]

MESSAGES = [
    (-26, "Sarah Mitchell", "Booking confirmation", "Email", "Outgoing",
     "Confirmed four walks for the month", "Yes", 5, "No", "", None),
    (-21, "Megan Foster", "Payment reminder", "Email", "Outgoing",
     "Reminder for an overdue invoice", "Yes", 4, "No", "", None),
    (-18, "Daniel Brooks", "Follow-up", "SMS", "Outgoing",
     "Checked in after Daisy's long run", "Yes", 5, "No",
     "Daisy slept all afternoon - very happy", None),
    (-16, "Chloe Bennett", "Complaint", "Phone call", "Incoming",
     "Visit ran 15 minutes late", "Yes", 3, "Yes",
     "Understood the traffic - asked for earlier slots", -14),
    (-12, "Luis Hernandez", "Thank you", "SMS", "Outgoing",
     "Thanks for the referral", "No", 5, "No", "", None),
    (-7, "Robert Nguyen", "Win-back offer", "Email", "Outgoing",
     "20% off the first walk back", "No", None, "No", "", 23),
    (-3, "Amelia Clarke", "Booking confirmation", "Email", "Outgoing",
     "Meet and greet booked for next week", "Yes", None, "No", "", None),
]

INVENTORY = [
    ("Waste bags (roll of 300)", "Cleaning & hygiene", "PetMart", "Roll",
     6.50, 12, 6, 24, -20, None, 9, ""),
    ("Training treats 500 g", "Treats & food", "PetMart", "Bag", 9.20, 4, 5,
     10, -14, 180, 6, ""),
    ("Enzyme cleaner 1 L", "Cleaning & hygiene", "CleanCo", "Bottle", 11.40,
     3, 2, 6, -25, 400, 2, ""),
    ("Slip lead", "Leads & harnesses", "PetMart", "Each", 8.75, 6, 3, 6, -18,
     None, 1, ""),
    ("Pet first aid kit", "First aid", "PetCare Academy", "Kit", 34.00, 2, 2,
     2, -60, 500, 0, "Check expiry every quarter"),
    ("Saline wound wash", "First aid", "Riverton Vet Clinic", "Bottle", 6.80,
     1, 2, 4, -30, 120, 1, ""),
    ("Emergency dry food 2 kg", "Treats & food", "PetMart", "Bag", 14.60, 2,
     1, 3, -35, 150, 1, "Only for emergency cover"),
    ("Reflective vest", "Equipment", "SafetyGear", "Each", 18.00, 3, 2, 2,
     -90, None, 0, ""),
]

REMINDERS = [
    ("Send October invoices", "Invoicing", 2, "Alex Morgan", "High",
     "In progress", "14 invoices to issue"),
    ("Chase Tom Reed first aid certificate", "Staff", -2, "Alex Morgan",
     "Urgent", "Not started", "Certificate expired"),
    ("Order waste bags and treats", "Inventory", 5, "Jamie Lee", "Medium",
     "Not started", "Two items at or below minimum"),
    ("Call Robert Nguyen - win-back", "Marketing", 7, "Alex Morgan",
     "Medium", "Not started", "Inactive for four months"),
    ("Review insurance renewal", "Admin", 30, "Alex Morgan", "Low",
     "Not started", ""),
]

#: monthly budget inputs: (budget revenue, budget costs)
BUDGET = [
    (4200, 1500), (4300, 1500), (4500, 1550), (4400, 1550),
    (4600, 1600), (4800, 1650), (5200, 1700), (5100, 1700),
    (4900, 1650), (4700, 1600), (4800, 1600), (5400, 1800),
]


def _build(cfg: Config) -> Sample:
    today = cfg.today
    s = Sample()

    # ---------------------------------------------------------- services
    for name, (cat, unit, mins, rate, extra, staff_cost, travel, hol,
               wkd) in SERVICES.items():
        s.services.append(dict(
            name=name, category=cat,
            description=f"{name} - {unit.lower()}, all care included",
            unit=unit, duration=mins, rate=rate, extra_pet=extra,
            hol_pct=hol, wkd_pct=wkd, travel=travel, staff_cost=staff_cost,
            active="Yes", notes=""))

    # ------------------------------------------------------------ clients
    for c in CLIENTS:
        row = {k: v for k, v in c.items() if k not in ("reg", "agreement")}
        row["reg_date"] = _day(today, c["reg"])
        row["agreement_date"] = (_day(today, c["agreement"])
                                 if c["agreement"] is not None else None)
        row["key_returned"] = (_day(today, c["key_returned"])
                               if c.get("key_returned") is not None else None)
        s.clients.append(row)

    # --------------------------------------------------------------- pets
    for (name, owner, species, breed, age, gender, weight, colour, temper,
         risk, handling, vacc) in PETS:
        s.pets.append(dict(
            name=name, owner=owner, type=species, breed=breed,
            dob=_day(today, age), gender=gender, weight=weight,
            colour=colour, microchip=f"9560000{1000 + len(s.pets):06d}",
            temperament=temper,
            behaviour="None noted" if risk == "None" else risk,
            allergies="None known", medical="None" if risk != "Medical risk"
            else "Hyperthyroid - daily medication",
            vet_name="Riverton Vet Clinic", vet_phone="+1 (555) 100 2000",
            vacc_expiry=_day(today, vacc), insurer="Pet Secure",
            feeding="As per the feeding card on the fridge",
            medication=("Felimazole 2.5mg" if name == "Milo" else "None"),
            walking="30-60 minutes a day", grooming="Brush weekly",
            risk=risk, handling=handling))

    # -------------------------------------------------------------- staff
    for st in STAFF:
        s.staff.append(dict(
            name=st["name"], role=st["role"], phone=st["phone"],
            email=st["email"], employment=st["employment"],
            start_date=_day(today, st["start"]), status=st["status"],
            pay_type=st["pay_type"], pay_rate=st["pay_rate"], cert=st["cert"],
            cert_expiry=_day(today, st["cert_expiry"]),
            availability=st["availability"], notes=st["notes"]))

    # ----------------------------------------------------------- bookings
    pet_by_name = {p["name"]: p for p in s.pets}
    for i, (offset, client, pet, service, hour, staff, status) in enumerate(
            BOOKING_PLAN):
        cat, unit, mins, rate, extra, staff_cost, travel, hol, wkd = \
            SERVICES[service]
        start_min = hour * 60
        end_min = (start_min + mins) % (24 * 60)
        qty = 2 if service == "Overnight Pet Sitting" else 1
        row = dict(
            client=client,
            pet=f"{pet} ({pet_by_name[pet]['owner']})",
            pet_count=1, service=service, date=_day(today, offset),
            start=_dt_time(hour, 0), end=_dt_time(end_min // 60, end_min % 60),
            qty=qty, booked_on=_day(today, offset - 4 - (i % 5)),
            distance=round(3 + (i * 1.7) % 9, 1) if travel == "Yes" else None,
            discount_pct=0.05 if client == "Sarah Mitchell" else None,
            override=None, staff=staff, status=status,
            cancel_reason="Client away" if status == "Cancelled" else None,
            repeats="Weekly" if service.startswith("Dog Walk") else "None",
            confirmed="Yes" if offset < 2 else "No",
            notes="Keys collected in advance" if qty == 2 else "")
        s.bookings.append(row)

    # ------------------------------------------------------------- visits
    for i, b in enumerate(s.bookings):
        if b["status"] != "Completed":
            continue
        dur = SERVICES[b["service"]][2]
        arrive_min = b["start"].hour * 60 + b["start"].minute + (i % 3) * 2
        depart_min = (arrive_min + dur) % (24 * 60)
        walk = SERVICES[b["service"]][0] in ("Dog walking",)
        s.visits.append(dict(
            booking=f"BK-{i + 1:04d}",
            arrive=_dt_time(arrive_min // 60, arrive_min % 60),
            depart=_dt_time(depart_min // 60, depart_min % 60),
            fed="N/A" if walk else "Yes", water="Yes",
            meds="Yes" if "Cat" in b["service"] and i % 2 else "N/A",
            potty=["Both", "Pee only", "Litter cleaned"][i % 3],
            mood=["Happy", "Calm", "Playful"][i % 3],
            appetite="Normal", health="All normal", incident="No",
            incident_ref="", update_sent="Yes", status="Completed",
            notes="Visit completed as planned"))

    # ---------------------------------------------------------- invoices
    manual = [
        ("Priya Raman", -26, "Dog walking - weekly package", 4, 25,
         "Paid", None),
        ("Megan Foster", -24, "Cat feeding visits", 6, 22, "Paid", None),
        ("Daniel Brooks", -22, "Dog walking - 60 min x 3", 3, 40, "Paid",
         None),
        ("Luis Hernandez", -18, "Dog walking - 30 min x 4", 4, 25, "Sent",
         None),
        ("Chloe Bennett", -15, "Puppy-style visits x 3", 3, 28, "Sent",
         None),
        ("Robert Nguyen", -60, "Final account - hall key", 1, 20, "Paid",
         None),
    ]
    # Invoices raised straight from a booking: the booking is found by its
    # client and day offset, so the invoice always names the right client.
    linked = [
        ("James Okafor", -12, "Overnight pet sitting for Luna", "Paid"),
        ("Sarah Mitchell", -7, "Dog walk for Max", "Sent"),
        ("Chloe Bennett", -1, "Drop-in visit for Poppy", "Draft"),
    ]
    invoices = []
    for client, offset, desc, qty, rate, status, _ in manual:
        invoices.append(dict(client=client, booking="", date=_day(today, offset),
                             description=desc, qty=qty, rate=rate, fees=None,
                             discount=None, status=status,
                             notes="Thank you for your business"
                             if status == "Paid" else ""))
    for client, offset, desc, status in linked:
        booking_index = next(
            i for i, row in enumerate(BOOKING_PLAN, start=1)
            if row[0] == offset and row[1] == client)
        invoices.append(dict(client=client,
                             booking=f"BK-{booking_index:04d}",
                             date=_day(today, offset), description=desc,
                             qty=None, rate=None, fees=None, discount=None,
                             status=status,
                             notes="Amount taken from the booking"))
    s.invoices = invoices

    # ---------------------------------------------------------- payments
    # (invoice index, days ago, method, amount, tip, refund)
    pay_plan = [
        (0, -25, "Bank transfer", 116.64, 0, None),
        (1, -23, "Card - online", 190.08, 0, None),
        (2, -21, "Card - in person", 259.20, 10, None),
        (5, -58, "Cash", 21.60, None, None),
        (6, -11, "Card - online", 100.00, 0, None),
        (7, -5, "Bank transfer", 50.00, 0, None),
    ]
    for inv_index, offset, method, amount, tip, refund in pay_plan:
        s.payments.append(dict(
            date=_day(today, offset),
            client=invoices[inv_index]["client"],
            invoice_no=f"{cfg.invoice_prefix}"
                       f"{cfg.invoice_start_number + inv_index}",
            amount=amount, tip=tip, refund=refund, method=method,
            reference=f"REF{10000 + inv_index * 37}",
            deposit="No", confirmed="Yes",
            reconciled="Yes" if offset < -3 else "No", notes=""))

    # ---------------------------------------------------------- expenses
    for (offset, cat, desc, supplier, amount, method, typ, pct, recur,
         receipt, approval) in EXPENSES:
        s.expenses.append(dict(
            date=_day(today, offset), category=cat, description=desc,
            supplier=supplier, amount=amount, method=method, type=typ,
            business_pct=pct, recurring=recur, receipt=receipt,
            approval=approval, notes=""))

    # ----------------------------------------------------------- mileage
    for offset, staff, client, purpose, start, end in MILEAGE_PLAN:
        s.mileage.append(dict(
            date=_day(today, offset), staff=staff, client=client,
            purpose=purpose, start_loc="Home office",
            end_loc=f"{client} - client home",
            start_odo=start, end_odo=end, notes=""))

    # ------------------------------------------------------------ health
    for (offset, pet, rtype, item, dosage, sched, given, by, status, supply,
         refill, cost, notified, notes) in HEALTH:
        owner = pet_by_name[pet]["owner"]
        s.health.append(dict(
            date=_day(today, offset), pet=f"{pet} ({owner})",
            type=rtype, item=item, dosage=dosage,
            sched_time=_dt_time(*map(int, sched.split(":"))),
            given_time=(_dt_time(*map(int, given.split(":")))
                        if given else None),
            given_by=by, status=status, supply=supply,
            refill_due=(_day(today, refill) if refill is not None else None),
            cost=cost, notified=notified, notes=notes))

    # --------------------------------------------------------- incidents
    for (offset, time_text, client, pet, staff, itype, sev, desc, action,
         vet, notified, follow, status, cost, claim) in INCIDENTS:
        s.incidents.append(dict(
            date=_day(today, offset),
            time=_dt_time(*map(int, time_text.split(":"))),
            client=client, pet=pet, reported_by=staff, booking="",
            type=itype, severity=sev, description=desc, action=action,
            vet_contacted=vet, owner_notified=notified,
            follow_up_due=_day(today, follow), status=status, cost=cost,
            claim=claim, notes=""))

    # ---------------------------------------------------------- messages
    for (offset, client, mtype, channel, direction, summary, reply, rating,
         complaint, feedback, follow) in MESSAGES:
        s.messages.append(dict(
            date=_day(today, offset), client=client, type=mtype,
            channel=channel, direction=direction, summary=summary,
            reply=reply, rating=rating, complaint=complaint,
            resolution="Resolved" if complaint == "Yes" else "Not required",
            follow_up_due=(_day(today, follow) if follow is not None
                           else None),
            follow_up_done="No" if follow is not None else "Yes",
            notes=feedback))

    # --------------------------------------------------------- inventory
    for (item, cat, supplier, unit, cost, qty, minimum, reorder, purchase,
         expiry, used, notes) in INVENTORY:
        s.inventory.append(dict(
            item=item, category=cat, supplier=supplier, unit=unit,
            unit_cost=cost, qty=qty, min_qty=minimum, reorder_qty=reorder,
            last_purchase=_day(today, purchase),
            expiry=(_day(today, expiry) if expiry is not None else None),
            used_month=used, notes=notes))

    # --------------------------------------------------------- reminders
    for (task, cat, due, owner, priority, status, notes) in REMINDERS:
        s.reminders.append(dict(
            task=task, category=cat, due=_day(today, due), owner=owner,
            priority=priority, status=status, notes=notes))

    # ------------------------------------------------------------ budget
    for revenue, costs in BUDGET:
        s.budget.append(dict(budget_revenue=revenue, budget_costs=costs))

    return s


def _dt_time(hour: int, minute: int = 0) -> _dt.time:
    return _dt.time(hour % 24, minute)
