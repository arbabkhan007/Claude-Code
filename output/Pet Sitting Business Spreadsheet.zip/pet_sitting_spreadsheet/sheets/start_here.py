"""`Start Here` - the welcome page: how to use the workbook and where things are."""

from __future__ import annotations

from ..config import Config, Palette
from ..layout import quote_sheet
from ..writer import SheetWriter

SHEET = "Start Here"
LAST_COL = 7

#: (tab, what it is for) - in the same order as the workbook tabs
TABS = [
    ("Dashboard", "Money, bookings and everything needing attention - open "
                  "this first each day."),
    ("Settings", "Your business details, tax, prices rules and alert days."),
    ("Lists", "Every drop down option. Edit here and the whole workbook follows."),
    ("Services", "Your service menu and rates - bookings are priced from here."),
    ("Clients", "Client database with contact, access and contract details."),
    ("Pets", "Pet profiles: routine, medical, vaccinations and safety notes."),
    ("Bookings", "Schedule and prices. Holidays, weekends and travel are "
                 "applied automatically."),
    ("Visit Log", "Proof of service for every visit, walk and overnight stay."),
    ("Health Log", "Medication doses, vaccinations and vet visits."),
    ("Incidents", "Incident reports with follow-up and owner notification."),
    ("Messages", "Client communication, reviews and complaints."),
    ("Invoices", "Automatic invoice numbers, tax, balances and ageing."),
    ("Payments", "Money received, tips, refunds and reconciliation."),
    ("Expenses", "Business costs with business use % and approval status."),
    ("Mileage", "Odometer log and mileage claim."),
    ("Staff", "Carers, certificates, pay and workload."),
    ("Inventory", "Supplies, stock levels, reorder points and expiry dates."),
    ("Reminders", "Reminder centre - tasks and deadlines with alerts."),
    ("Reports", "Monthly, service and category reports - all calculated."),
    ("Budget", "Plan each month and track actual against budget."),
    ("Print Invoice", "A printable invoice - type the number and print."),
    ("Print Pet Care", "A printable care sheet for a pet - choose and print."),
    ("Print Visit", "A printable visit report for one booking."),
    ("Print Forms", "Blank forms: intake, key receipt, medication log, vet authority."),
    ("Help", "How the workbook works, password and data safety tips."),
]


def build(book, fmts, cfg: Config, reg) -> SheetWriter:
    s = SheetWriter(book, fmts, cfg, reg, SHEET, tab_color=Palette.accent,
                    landscape=False)
    s.set_col(0, 0, 3)
    s.set_col(1, 1, 22)
    s.set_col(2, 2, 62)
    s.set_col(3, LAST_COL, 12)
    s.banner(cfg.product_name,
             f"{cfg.product_subtitle}.  Version {cfg.version} by {cfg.author}.",
             LAST_COL, nav=False)

    r = 3
    r = s.section(r, "Welcome", LAST_COL, first_col=1)
    r = s.note(r, "Thank you for choosing this workbook. It runs your pet "
                  "sitting and dog walking business from one file: clients, "
                  "pets, bookings, visit logs, health records, invoices, "
                  "payments, expenses, mileage, staff and reports. The cream "
                  "cells are yours to type in. Grey cells are calculated and "
                  "locked, so the maths stays right.", LAST_COL, first_col=1,
               height=54)
    r += 1

    r = s.section(r, "Get started in five steps", LAST_COL, first_col=1)
    steps = [
        "1.  Settings - enter your business details, tax setup and alert days.",
        "2.  Services - check the prices and rules for each service you sell.",
        "3.  Clients and Pets - add your clients first, then their pets.",
        "4.  Bookings - schedule visits. Prices and surcharges calculate automatically.",
        "5.  Visit Log, Invoices and Payments - record what happened and what you were paid.",
    ]
    for line in steps:
        s.merge(r, 1, LAST_COL, line, fmts.chrome("label"))
        s.row_height(r, 18)
        r += 1
    r += 1

    r = s.section(r, "What is in this workbook", LAST_COL, first_col=1)
    s.write(r, 1, "Tab (click to open)", fmts.chrome("header_left"))
    s.write(r, 2, "What it is for", fmts.chrome("header_left"))
    s.ws.set_row(r, 22)
    r += 1
    link_fmt = fmts.chrome("nav", font_size=10)
    desc_fmt = fmts.chrome("label")
    for tab, desc in TABS:
        s.ws.write_url(r, 1, f"internal:{quote_sheet(tab)}!A1", link_fmt,
                       tab)
        s.write(r, 2, desc, desc_fmt)
        s.row_height(r, 17)
        r += 1
    r += 1

    r = s.section(r, "Colour key", LAST_COL, first_col=1)
    s.write(r, 1, "Cream cell", fmts.chrome("legend_input"))
    s.write(r, 2, "You type here.", fmts.chrome("label"))
    r += 1
    s.write(r, 1, "Grey cell", fmts.chrome("legend_calc"))
    s.write(r, 2, "Calculated and locked. Do not type over it.", fmts.chrome("label"))
    r += 2

    r = s.note(r, "This workbook is protected to keep formulas safe. "
                  f"The protection password is '{cfg.password}' - see the Help "
                  "tab. Your records stay on your computer; keep a dated backup "
                  "copy each month.", LAST_COL, first_col=1, height=40)

    s.finish(gridlines=False)
    return s
