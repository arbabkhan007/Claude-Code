"""`Calc` - hidden engine: twelve month rows that feed the dashboard and reports.

The sheet is hidden and protected.  Every figure on it is a formula, so the
Dashboard, Reports and Budget tabs never have to repeat the date arithmetic.
"""

from __future__ import annotations

from ..config import Config, Palette
from ..layout import Col, SheetSpec
from .common import blank

NAME = "Calc"


def _between(sheet: str, key: str) -> str:
    """Criteria pair: the given date column falls inside this month row."""
    return (f'[[{sheet}.{key}]],">="&{{m_start}}{{r}},'
            f'[[{sheet}.{key}]],"<="&{{m_end}}{{r}}')


def spec(cfg: Config) -> SheetSpec:
    columns = [
        Col("n", "Month no.", 9, "int", formula='=ROW()-4'),
        Col("m_start", "Month start", 12, "date",
            formula='=EDATE(FY_Start,{n}{r}-1)'),
        Col("m_end", "Month end", 12, "date",
            formula='=EDATE({m_start}{r},1)-1'),
        Col("label", "Month", 11, "text",
            formula='=TEXT({m_start}{r},"mmm yyyy")'),
        Col("bookings", "Bookings", 10, "int",
            formula='=COUNTIFS(' + _between("Bookings", "date") +
                    ',[[Bookings.status]],"<>Cancelled")'),
        Col("booked_value", "Booked value", 12, "money",
            formula='=SUMIFS([[Bookings.total]],' + _between("Bookings", "date") +
                    ',[[Bookings.status]],"<>Cancelled")'),
        Col("invoiced", "Invoiced", 12, "money",
            formula='=SUMIFS([[Invoices.total]],' + _between("Invoices", "date") +
                    ',[[Invoices.status]],"<>Draft",'
                    '[[Invoices.status]],"<>Cancelled")'),
        Col("received", "Received", 12, "money",
            formula='=SUMIFS([[Payments.received]],' +
                    _between("Payments", "date") + ')'),
        Col("expenses", "Business expenses", 12, "money",
            formula='=SUMIFS([[Expenses.business_amt]],' +
                    _between("Expenses", "date") + ')'),
        Col("mileage", "Mileage claim", 12, "money",
            formula='=SUMIFS([[Mileage.claim]],' +
                    _between("Mileage", "date") + ')'),
        Col("costs", "Total costs", 12, "money",
            formula='=ROUND({expenses}{r}+{mileage}{r},2)'),
        Col("profit", "Profit (cash)", 12, "money",
            formula='=ROUND({received}{r}-{costs}{r},2)'),
    ]

    return SheetSpec(
        name=NAME,
        title="Calculation engine (hidden)",
        subtitle="Monthly totals used by the Dashboard, Reports and Budget.",
        columns=columns,
        rows=12,
        tab_color=Palette.grey_text,
        freeze_cols=1,
        samples=[],
        help_text="Hidden helper sheet. Do not edit.",
    )
