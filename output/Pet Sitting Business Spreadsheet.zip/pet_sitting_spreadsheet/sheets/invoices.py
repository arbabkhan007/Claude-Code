"""`Invoices` - invoice register with automatic numbering, tax, balances and ageing."""

from __future__ import annotations

from ..config import Config, Palette
from ..layout import DATA_ROW, Col, SheetSpec
from ..sample_data import get as sample
from ..writer import date_check, list_from, number_check, yes_no
from .common import alert_cf, blank, month_col, owing_cf, status_cf

NAME = "Invoices"


def spec(cfg: Config) -> SheetSpec:
    columns = [
        Col("invoice_no", "Invoice no.", 12, "id",
            formula=blank("client",
                          f'InvoicePrefix&TEXT(InvoiceStartNo+ROW()-{DATA_ROW - 1},'
                          '"0000")'),
            note="Numbered automatically from the first invoice number on the "
                 "Settings tab. Keep rows in order so numbers stay unique."),
        Col("client", "Client", 20, "text",
            validate=list_from("ClientNames")),
        Col("date", "Invoice date", 12, "date", validate=date_check()),
        Col("due", "Due date", 12, "date",
            formula=blank("date", '{date}{r}+PaymentTermsDays')),
        Col("booking", "Booking ID", 12, "text",
            validate=list_from("BookingIDs"),
            note="Link a booking and the invoice amount comes straight from "
                 "it. Leave blank to bill with Qty x Rate instead."),
        Col("description", "Description of service", 36, "wrap"),
        Col("qty", "Qty", 8, "number", validate=number_check(0, 10000)),
        Col("rate", "Rate", 11, "money", validate=number_check(0, 100000)),
        Col("line_amount", "Amount", 12, "money",
            formula=blank("client",
                          'IF({booking}{r}<>"",IFERROR(INDEX([[Bookings.subtotal]],'
                          'MATCH({booking}{r},[[Bookings.id]],0)),0),'
                          'ROUND({qty}{r}*{rate}{r},2))')),
        Col("fees", "Extra fees", 10, "money", validate=number_check(0, 100000)),
        Col("discount", "Discount", 10, "money",
            validate=number_check(0, 100000)),
        Col("subtotal", "Subtotal", 12, "money",
            formula=blank("client",
                          'ROUND({line_amount}{r}+{fees}{r}-{discount}{r},2)')),
        Col("tax", "Tax", 10, "money",
            formula=blank("client",
                          'IF(TaxRegistered<>"Yes",0,IF(PricesIncludeTax="Yes",'
                          'ROUND({subtotal}{r}-{subtotal}{r}/(1+TaxRate),2),'
                          'ROUND({subtotal}{r}*TaxRate,2)))')),
        Col("total", "Invoice total", 13, "money",
            formula=blank("client",
                          'IF(PricesIncludeTax="Yes",{subtotal}{r},'
                          'ROUND({subtotal}{r}+{tax}{r},2))'),
            cf=[{"type": "data_bar", "bar_color": "#2E7D8F"}]),
        Col("paid", "Paid so far", 12, "money",
            formula=blank("client",
                          'SUMIFS([[Payments.net]],[[Payments.invoice_no]],'
                          '{invoice_no}{r})')),
        Col("balance", "Balance due", 12, "money",
            formula=blank("client",
                          'ROUND(IF({status}{r}="Cancelled",0,'
                          '{total}{r}-{paid}{r}),2)'),
            cf=owing_cf()),
        Col("status", "Invoice status", 13, "status",
            validate=list_from("InvoiceStatusList"), cf=status_cf(),
            note="You set Draft / Sent / Cancelled. Payment status is "
                 "calculated from the Payments tab."),
        Col("pay_status", "Payment status", 16, "status",
            formula=blank(
                "client",
                'IF({status}{r}="Cancelled","Cancelled",'
                'IF({status}{r}="Draft","Draft",'
                'IF({balance}{r}<=0.004,"Paid",'
                'IF({paid}{r}>0.004,IF(AND({due}{r}<>"",TODAY()>{due}{r}),'
                '"Overdue - part paid","Partially paid"),'
                'IF(AND({due}{r}<>"",TODAY()>{due}{r}),"Overdue","Unpaid")))))'),
            cf=status_cf() + [{"type": "text", "criteria": "containing",
                               "value": "Overdue", "fmt": "bad"}]),
        Col("days_overdue", "Days overdue", 10, "int",
            formula=blank("client",
                          'IF(OR({balance}{r}<=0.004,{status}{r}="Draft",'
                          '{due}{r}=""),"",MAX(0,TODAY()-{due}{r}))'),
            cf=[{"type": "cell", "criteria": ">", "value": 0,
                 "fmt": "bad"}]),
        Col("ageing", "Ageing", 13, "status",
            formula=blank("client",
                          'IF({balance}{r}<=0.004,"Paid",'
                          'IF({days_overdue}{r}="","Not yet due",'
                          'IF({days_overdue}{r}<=30,"1-30 days",'
                          'IF({days_overdue}{r}<=60,"31-60 days",'
                          'IF({days_overdue}{r}<=90,"61-90 days","90+ days")))))'),
            cf=[{"type": "text", "criteria": "containing", "value": "Paid",
                 "fmt": "good"},
                {"type": "text", "criteria": "containing",
                 "value": "90+", "fmt": "bold_bad"},
                {"type": "text", "criteria": "containing",
                 "value": "61-90", "fmt": "bad"},
                {"type": "text", "criteria": "containing",
                 "value": "31-60", "fmt": "warn"}]),
        Col("sent_on", "Sent on", 12, "date", validate=date_check()),
        Col("reminder_sent", "Reminder sent", 10, "flag", validate=yes_no(),
            cf=status_cf()),
        Col("notes", "Invoice notes", 30, "wrap"),
        month_col("date"),
        Col("alert", "Action needed", 26, "status",
            formula=blank(
                "client",
                'IF({status}{r}="Draft","Action - send the draft",'
                'IF({pay_status}{r}="Overdue","Overdue - chase payment",'
                'IF({pay_status}{r}="Overdue - part paid",'
                '"Overdue - chase the balance",'
                'IF(AND({balance}{r}>0.004,{due}{r}<>"",'
                '{due}{r}-TODAY()<=ReminderLeadDays,{due}{r}>=TODAY()),'
                '"Due soon - send a reminder","OK"))))'),
            cf=alert_cf()),
    ]

    return SheetSpec(
        name=NAME,
        title="Invoices",
        subtitle="Automatic numbering, due dates, tax, balances, ageing and "
                 "overdue alerts - link a booking and the amount follows.",
        columns=columns,
        rows=cfg.row_count(NAME),
        tab_color=Palette.good_text,
        freeze_cols=2,
        samples=sample(cfg).invoices,
        help_text="Pick the client to create the invoice number. Link a "
                  "Booking ID to bill its amount, or use Qty x Rate for "
                  "anything custom.",
    )
