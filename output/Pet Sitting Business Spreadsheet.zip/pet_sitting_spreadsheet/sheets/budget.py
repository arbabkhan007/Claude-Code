"""`Budget` - plan each month's income and costs, then see actual against plan."""

from __future__ import annotations

from ..config import Config, Palette
from ..sample_data import get as sample
from ..writer import SheetWriter

SHEET = "Budget"
LAST_COL = 9


def build(book, fmts, cfg: Config, reg) -> SheetWriter:
    s = SheetWriter(book, fmts, cfg, reg, SHEET, tab_color=Palette.accent)
    s.set_col(0, 0, 14)
    s.set_col(1, LAST_COL, 14)
    s.banner("Budget vs Actual",
             "Type the budget for each month in the cream columns. Actual "
             "figures and variances fill in from the rest of the workbook.",
             LAST_COL)

    r = s.section(3, "Monthly plan", LAST_COL)
    heads = ["Month", "Budget income", "Actual received", "Income variance",
             "Budget costs", "Actual costs", "Cost variance",
             "Budget profit", "Actual profit"]
    r = s.table_head(r, 0, heads)
    first = r
    plan = sample(cfg).budget if cfg.include_sample_data else []
    input_money = fmts.input("money")
    calc_money = fmts.calc("money")
    label_fmt = fmts.calc("text")

    for i in range(12):
        excel_row = r + 1
        calc_row = reg["Calc"].first_data_row + i
        s.ws.write_formula(r, 0, f"={reg.cell('Calc', 'label', calc_row)}",
                           label_fmt)
        income, costs = (plan[i]["budget_revenue"], plan[i]["budget_costs"]) \
            if i < len(plan) else (None, None)
        s.write(r, 1, income, input_money)
        s.ws.write_formula(r, 2, f"={reg.cell('Calc', 'received', calc_row)}",
                           calc_money)
        s.ws.write_formula(r, 3, f'=IF(B{excel_row}="","",C{excel_row}-B{excel_row})',
                           calc_money)
        s.write(r, 4, costs, input_money)
        s.ws.write_formula(r, 5, f"={reg.cell('Calc', 'costs', calc_row)}",
                           calc_money)
        s.ws.write_formula(r, 6, f'=IF(E{excel_row}="","",F{excel_row}-E{excel_row})',
                           calc_money)
        s.ws.write_formula(r, 7, f'=IF(OR(B{excel_row}="",E{excel_row}=""),"",'
                                 f'B{excel_row}-E{excel_row})', calc_money)
        s.ws.write_formula(r, 8, f"=C{excel_row}-F{excel_row}", calc_money)
        r += 1

    last = r - 1
    total_label = fmts.chrome("total_label")
    total_val = fmts.chrome("total_value", num_format=cfg.money_format)
    s.ws.write(r, 0, "Full year", total_label)
    for col in range(1, LAST_COL + 1):
        letter = chr(ord("A") + col)
        s.ws.write_formula(r, col, f"=SUM({letter}{first + 1}:{letter}{last + 1})",
                           total_val)
    r += 2

    r = s.section(r, "Quick check", LAST_COL)
    checks = [
        ("Income on track to date",
         f'=IF(SUMIFS(B{first + 1}:B{last + 1},B{first + 1}:B{last + 1},">0")=0,"",'
         f'IF(SUM(C{first + 1}:C{last + 1})>=SUM(B{first + 1}:B{last + 1})*'
         f'MONTH(TODAY())/12,"Yes - ahead of plan","No - behind plan"))'),
        ("Costs within budget to date",
         f'=IF(SUM(F{first + 1}:F{last + 1})<=SUM(E{first + 1}:E{last + 1})*'
         f'MONTH(TODAY())/12,"Yes","No - over budget")'),
    ]
    for label, formula in checks:
        s.merge(r, 0, 2, label, fmts.chrome("label_bold"))
        s.ws.merge_range(r, 3, r, 5, "", fmts.calc("status"))
        s.ws.write_formula(r, 3, formula, fmts.calc("status"))
        r += 1
    r += 1
    s.note(r, "Tip: budgets are spread evenly across the year for the quick "
              "check. Adjust the cream cells as your plan changes.",
           LAST_COL, first_col=0, height=28)

    s.ws.conditional_format(first, 3, last, 3, {
        "type": "cell", "criteria": "<", "value": 0, "format": fmts.cf("bad")})
    s.ws.conditional_format(first, 6, last, 6, {
        "type": "cell", "criteria": ">", "value": 0, "format": fmts.cf("bad")})
    s.ws.conditional_format(first, 8, last, 8, {
        "type": "cell", "criteria": "<", "value": 0, "format": fmts.cf("bad")})

    s.finish(gridlines=False)
    return s
