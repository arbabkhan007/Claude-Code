"""`Bookings` - the scheduling engine: prices, surcharges, conflicts and alerts."""

from __future__ import annotations

from ..config import Config, Palette
from ..layout import Col, SheetSpec
from ..sample_data import get as sample
from ..writer import date_check, list_from, number_check, yes_no
from .common import alert_cf, blank, id_col, month_col, status_cf

NAME = "Bookings"


def _svc(field: str, fallback: str = '""') -> str:
    """INDEX/MATCH into the Services register for the booked service."""
    return (f'IFERROR(INDEX([[Services.{field}]],'
            f'MATCH({{service}}{{r}},[[Services.name]],0)),{fallback})')


def spec(cfg: Config) -> SheetSpec:
    conflict = ('SUMPRODUCT(([[Bookings.staff]]={staff}{r})'
                '*([[Bookings.date]]={date}{r})'
                '*([[Bookings.start]]<{end}{r})'
                '*([[Bookings.end]]>{start}{r})'
                '*([[Bookings.status]]<>"Cancelled"))')

    columns = [
        id_col("client", "BookingPrefix", header="Booking ID", width=12),
        Col("client", "Client", 20, "text",
            validate=list_from("ClientNames")),
        Col("pet", "Pet", 24, "text", validate=list_from("PetLabels")),
        Col("pet_count", "No. of pets", 9, "int",
            validate=number_check(1, 20, decimal=False),
            note="Blank counts as 1. Each extra pet is charged the additional "
                 "pet fee from Services."),
        Col("service", "Service", 24, "text",
            validate=list_from("ServiceNames")),
        Col("date", "Date", 12, "date", validate=date_check()),
        Col("day", "Day", 7, "flag",
            formula=blank("date", 'TEXT({date}{r},"ddd")')),
        Col("start", "Start", 9, "time"),
        Col("end", "End", 9, "time"),
        Col("hours", "Hours", 8, "number",
            formula='=IF(OR({start}{r}="",{end}{r}=""),"",'
                    'ROUND(({end}{r}-{start}{r}+IF({end}{r}<{start}{r},1,0))'
                    '*24,2))'),
        Col("qty", "Visits / nights", 9, "number",
            validate=number_check(0, 1000),
            note="Number of visits, nights or hours being billed. Blank "
                 "counts as 1."),
        Col("unit", "Billing unit", 11, "text",
            formula=blank("service", _svc("unit"))),
        Col("rate", "Rate", 11, "money",
            formula=blank("service", _svc("rate", "0"))),
        Col("pet_rate", "Extra pet rate", 10, "money", hidden=True,
            formula=blank("service",
                          f'IF({_svc("extra_pet", "0")}=0,'
                          'ExtraPetFeeDefault,' + _svc("extra_pet", "0")
                          + ')')),
        Col("hol_pct", "Holiday %", 9, "percent", hidden=True,
            formula=blank("service",
                          f'IF({_svc("hol_pct", "0")}=0,HolidaySurcharge,'
                          + _svc("hol_pct", "0") + ')')),
        Col("wkd_pct", "Weekend %", 9, "percent", hidden=True,
            formula=blank("service",
                          f'IF({_svc("wkd_pct", "0")}=0,WeekendSurcharge,'
                          + _svc("wkd_pct", "0") + ')')),
        Col("travel_flag", "Travel billable", 9, "flag", hidden=True,
            formula=blank("service", _svc("travel", '"No"'))),
        Col("base", "Base charge", 12, "money",
            formula=blank(
                "service",
                'ROUND(IF({unit}{r}="Per hour",{rate}{r}*IF({hours}{r}="",1,'
                '{hours}{r}),{rate}{r}*IF({qty}{r}="",1,{qty}{r})),2)')),
        Col("extra_pet_fee", "Extra pet fee", 11, "money",
            formula=blank("service",
                          'ROUND(MAX(0,IF({pet_count}{r}="",1,{pet_count}{r})'
                          '-1)*{pet_rate}{r},2)')),
        Col("holiday", "Public holiday?", 9, "flag",
            formula=blank("date",
                          'IF(COUNTIF(HolidayDates,{date}{r})>0,"Yes","No")'),
            cf=[{"type": "text", "criteria": "containing", "value": "Yes",
                 "fmt": "warn"}]),
        Col("weekend", "Weekend?", 9, "flag",
            formula=blank("date", 'IF(WEEKDAY({date}{r},2)>5,"Yes","No")')),
        Col("surcharge", "Surcharges", 11, "money",
            formula=blank("service",
                          'ROUND(({base}{r}+{extra_pet_fee}{r})*'
                          '(IF({holiday}{r}="Yes",{hol_pct}{r},0)+'
                          'IF({weekend}{r}="Yes",{wkd_pct}{r},0)),2)')),
        Col("distance", "Travel distance", 10, "number1",
            validate=number_check(0, 2000)),
        Col("travel_fee", "Travel fee", 10, "money",
            formula=blank("service",
                          'IF({travel_flag}{r}<>"Yes",0,IF({distance}{r}="",0,'
                          'ROUND(MAX(0,{distance}{r}-FreeTravelDistance)*'
                          'TravelFeeRate,2)))')),
        Col("booked_on", "Booked on", 12, "date", validate=date_check(),
            note="Date the request came in. Bookings made within the "
                 "last-minute window attract the emergency fee."),
        Col("rush_fee", "Last-minute fee", 10, "money",
            formula=blank("date",
                          'IF({booked_on}{r}="",0,IF({date}{r}-{booked_on}{r}'
                          '<=LastMinuteDays,EmergencyFee,0))')),
        Col("discount_pct", "Discount %", 9, "percent",
            validate=number_check(0, 1)),
        Col("discount", "Discount", 11, "money",
            formula=blank("service",
                          'ROUND(({base}{r}+{extra_pet_fee}{r}+{surcharge}{r}+'
                          '{travel_fee}{r}+{rush_fee}{r})*'
                          'IF({discount_pct}{r}="",0,{discount_pct}{r}),2)')),
        Col("override", "Price override", 11, "money",
            validate=number_check(0, 100000),
            note="Only fill this in to force a price. Note the reason on the "
                 "booking notes."),
        Col("subtotal", "Subtotal (before tax)", 13, "money",
            formula=blank("service",
                          'IF({override}{r}<>"",{override}{r},'
                          'ROUND({base}{r}+{extra_pet_fee}{r}+{surcharge}{r}+'
                          '{travel_fee}{r}+{rush_fee}{r}-{discount}{r},2))')),
        Col("tax", "Tax", 10, "money",
            formula=blank("service",
                          'IF(TaxRegistered<>"Yes",0,IF(PricesIncludeTax="Yes",'
                          'ROUND({subtotal}{r}-{subtotal}{r}/(1+TaxRate),2),'
                          'ROUND({subtotal}{r}*TaxRate,2)))')),
        Col("total", "Booking total", 13, "money",
            formula=blank("service",
                          'IF(PricesIncludeTax="Yes",{subtotal}{r},'
                          'ROUND({subtotal}{r}+{tax}{r},2))'),
            cf=[{"type": "data_bar", "bar_color": "#2E7D8F"}]),
        Col("staff", "Assigned to", 16, "text",
            validate=list_from("StaffNames")),
        Col("status", "Status", 13, "status",
            validate=list_from("BookingStatusList"), cf=status_cf()),
        Col("confirmed", "Confirmed with client", 11, "flag",
            validate=yes_no(), cf=status_cf()),
        Col("repeats", "Repeats", 12, "text",
            validate=list_from("RecurringList")),
        Col("cancel_reason", "Cancellation reason", 18, "text",
            validate=list_from("CancelReasonList")),
        Col("conflict", "Schedule check", 18, "status",
            formula=('=IF(OR({date}{r}="",{staff}{r}="",{start}{r}="",'
                     '{end}{r}=""),"",IF(' + conflict +
                     '>1,"Conflict - double booked","OK"))'),
            cf=alert_cf()),
        Col("visit_logged", "Visit logged", 10, "flag",
            formula=blank("id",
                          'IF(COUNTIF([[Visit Log.booking]],{id}{r})>0,'
                          '"Yes","No")'),
            cf=status_cf()),
        Col("invoice_no", "Invoice no.", 12, "text",
            formula=blank("id",
                          'IFERROR(INDEX([[Invoices.invoice_no]],'
                          'MATCH({id}{r},[[Invoices.booking]],0)),"")')),
        Col("pay_status", "Payment status", 15, "status",
            formula=blank("id",
                          'IF({invoice_no}{r}="","Not invoiced",'
                          'IFERROR(INDEX([[Invoices.pay_status]],'
                          'MATCH({invoice_no}{r},[[Invoices.invoice_no]],0)),""))'),
            cf=status_cf() + [{"type": "text", "criteria": "containing",
                               "value": "Not invoiced", "fmt": "warn"}]),
        Col("notes", "Notes & special requests", 34, "wrap"),
        month_col("date"),
        Col("alert", "Action needed", 26, "status",
            formula=blank(
                "date",
                'IF({status}{r}="Cancelled","Cancelled",'
                'IF(LEFT({conflict}{r},8)="Conflict","Conflict - check staff",'
                'IF(AND({date}{r}<TODAY(),OR({status}{r}="Pending",'
                '{status}{r}="Confirmed",{status}{r}="Enquiry")),'
                '"Overdue - update status",'
                'IF(AND({status}{r}="Completed",{visit_logged}{r}="No"),'
                '"Action - log the visit",'
                'IF({date}{r}=TODAY(),"Today",'
                'IF(AND({date}{r}>TODAY(),{date}{r}-TODAY()<=ReminderLeadDays,'
                '{confirmed}{r}<>"Yes"),"Action - not yet confirmed",'
                '"OK"))))))'),
            cf=alert_cf()),
    ]

    return SheetSpec(
        name=NAME,
        title="Bookings & Schedule",
        subtitle="Every booking priced automatically from the Services tab, "
                 "with holiday, weekend, extra pet, travel and last-minute "
                 "rules applied.",
        columns=columns,
        rows=cfg.row_count(NAME),
        tab_color=Palette.accent,
        freeze_cols=3,
        samples=sample(cfg).bookings,
        help_text="Fill the cream cells from left to right. Grey cells - "
                  "prices, surcharges, totals, conflict checks and alerts - "
                  "are calculated and locked.",
    )
