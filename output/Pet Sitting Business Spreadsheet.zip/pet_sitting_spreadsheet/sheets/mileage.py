"""`Mileage` - odometer log and mileage claim for business driving."""

from __future__ import annotations

from ..config import Config, Palette
from ..layout import Col, SheetSpec
from ..sample_data import get as sample
from ..writer import date_check, list_from, number_check
from .common import alert_cf, blank, id_col, month_col

NAME = "Mileage"


def spec(cfg: Config) -> SheetSpec:
    unit = cfg.distance_unit
    columns = [
        id_col("staff", '"MI-"', header="Trip ID", width=10),
        Col("date", "Date", 12, "date", validate=date_check()),
        Col("staff", "Driver", 15, "text", validate=list_from("StaffNames")),
        Col("client", "Client / destination", 20, "text",
            validate=list_from("ClientNames")),
        Col("purpose", "Purpose", 15, "text",
            validate=list_from("TripPurposeList")),
        Col("start_loc", "From", 16, "text"),
        Col("end_loc", "To", 24, "text"),
        Col("start_odo", "Odometer start", 11, "number1",
            validate=number_check(0, 9999999)),
        Col("end_odo", "Odometer end", 11, "number1",
            validate=number_check(0, 9999999)),
        Col("distance", f"Distance ({unit})", 11, "number1",
            formula=blank("end_odo",
                          'IF({end_odo}{r}<{start_odo}{r},0,'
                          'ROUND({end_odo}{r}-{start_odo}{r},1))')),
        Col("claim", "Claim amount", 12, "money",
            formula=blank("distance",
                          'ROUND({distance}{r}*MileageRate,2)')),
        Col("notes", "Notes", 28, "wrap"),
        month_col("date"),
        Col("alert", "Action needed", 24, "status",
            formula=blank(
                "date",
                'IF({end_odo}{r}="","Action - record the end reading",'
                'IF({end_odo}{r}<{start_odo}{r},'
                '"Check odometer - end is lower",'
                '"OK"))'),
            cf=alert_cf()),
    ]

    return SheetSpec(
        name=NAME,
        title="Mileage Log",
        subtitle=f"Record every business trip. Distance and the mileage claim "
                 f"are calculated from the odometer readings and the rate on "
                 f"the Settings tab.",
        columns=columns,
        rows=cfg.row_count(NAME),
        tab_color=Palette.primary_mid,
        freeze_cols=2,
        samples=sample(cfg).mileage,
        help_text="Enter the start and end odometer readings. Distance is "
                  f"worked out in {unit} and multiplied by the mileage rate.",
    )
