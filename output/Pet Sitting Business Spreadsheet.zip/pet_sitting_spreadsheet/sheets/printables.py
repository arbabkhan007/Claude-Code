"""Printable pages: invoice, pet care sheet, visit report and blank forms.

Each page has one cream input cell (an invoice number, pet or booking ID).
Everything else is looked up from the registers, so a page always matches
the record it is printed for.
"""

from __future__ import annotations

from ..config import Config, Palette
from ..sample_data import get as sample
from ..writer import SheetWriter


def _lookup(reg, sheet: str, key: str, match_sheet_key: str,
            input_cell: str) -> str:
    """INDEX/MATCH a register value using the page's input cell."""
    return (f'=IFERROR(INDEX({reg.rng(sheet, key)},'
            f'MATCH({input_cell},{reg.rng(sheet, match_sheet_key)},0)),"")')


def _pair(s: SheetWriter, fmts, row: int, label: str, formula: str,
          label_col: int, value_col: int, value_end: int, style: str = "text"):
    s.merge(row, label_col, value_col - 1, label, fmts.chrome("form_label"))
    fmt = fmts.calc(style, align="left")
    s.ws.merge_range(row, value_col, row, value_end, "", fmt)
    s.ws.write_formula(row, value_col, formula, fmt)


def _business_block(s: SheetWriter, fmts, row: int) -> int:
    lines = [
        ("Business", "=Biz_Name"),
        ("Address", '=Biz_Address&", "&Biz_City&" "&Biz_State&" "&Biz_Post'),
        ("Phone / email", '=Biz_Phone&"  |  "&Biz_Email'),
        ("Tax / business no.", "=Biz_TaxID"),
    ]
    for label, formula in lines:
        s.merge(row, 0, 1, label, fmts.chrome("form_label"))
        s.ws.merge_range(row, 2, row, 3, "", fmts.calc("text", align="left"))
        s.ws.write_formula(row, 2, formula, fmts.calc("text", align="left"))
        row += 1
    return row


# ---------------------------------------------------------------- invoice
def build_invoice(book, fmts, cfg: Config, reg) -> SheetWriter:
    s = SheetWriter(book, fmts, cfg, reg, "Print Invoice",
                    tab_color=Palette.good_text, landscape=False)
    last = 7
    s.set_col(0, 0, 14)
    s.set_col(1, 1, 14)
    s.set_col(2, 3, 16)
    s.set_col(4, 4, 10)
    s.set_col(5, 5, 12)
    s.set_col(6, 7, 14)
    s.banner("Invoice", "Type an invoice number in the cream cell. Print or "
             "save as PDF.", last, nav=False)

    r = 3
    r = _business_block(s, fmts, r)
    r += 1
    first = sample(cfg).invoices[0] if cfg.include_sample_data else None
    number = (f"{cfg.invoice_prefix}{cfg.invoice_start_number}"
              if first else "")
    s.merge(r, 4, 5, "Invoice number", fmts.chrome("form_label"))
    s.write(r, 6, number, fmts.input("text", bold=True))
    s.merge(r, 7, 7, "", fmts.chrome("form_label"))
    input_cell = f"$G${r + 1}"
    top = r
    r += 1
    detail = [
        ("Bill to", "client", "text"),
        ("Invoice date", "date", "date"),
        ("Due date", "due", "date"),
        ("Status", "pay_status", "status"),
    ]
    for offset, (label, key, style) in enumerate(detail):
        s.merge(top + 1 + offset, 4, 5, label, fmts.chrome("form_label"))
        fmt = fmts.calc(style, align="left")
        s.ws.merge_range(top + 1 + offset, 6, top + 1 + offset, 7, "", fmt)
        s.ws.write_formula(top + 1 + offset, 6,
                           _lookup(reg, "Invoices", key, "invoice_no", input_cell),
                           fmt)
    r = max(r, top + 1 + len(detail)) + 1

    # line items ----------------------------------------------------------
    s.ws.merge_range(r, 0, r, 3, "Description", fmts.chrome("header_left"))
    s.write(r, 4, "Qty", fmts.chrome("header"))
    s.write(r, 5, "Rate", fmts.chrome("header"))
    s.ws.merge_range(r, 6, r, 7, "Amount", fmts.chrome("header"))
    s.row_height(r, 20)
    r += 1
    s.ws.merge_range(r, 0, r, 3, "", fmts.calc("wrap", align="left"))
    s.ws.write_formula(r, 0, _lookup(reg, "Invoices", "description",
                                     "invoice_no", input_cell),
                       fmts.calc("wrap", align="left"))
    s.ws.write_formula(r, 4, _lookup(reg, "Invoices", "qty", "invoice_no",
                                     input_cell), fmts.calc("number"))
    s.ws.write_formula(r, 5, _lookup(reg, "Invoices", "rate", "invoice_no",
                                     input_cell), fmts.calc("money"))
    s.ws.merge_range(r, 6, r, 7, "", fmts.calc("money"))
    s.ws.write_formula(r, 6, _lookup(reg, "Invoices", "line_amount",
                                     "invoice_no", input_cell),
                       fmts.calc("money"))
    s.row_height(r, 30)
    r += 2

    totals = [
        ("Subtotal", "subtotal", False),
        ('=TaxName&" @ "&TEXT(TaxRate,"0.0%")', "tax", False),
        ("Invoice total", "total", True),
        ("Paid so far", "paid", False),
        ("Balance due", "balance", True),
    ]
    for label, key, bold in totals:
        if label.startswith("="):
            s.ws.merge_range(r, 4, r, 5, "", fmts.chrome("label_right"))
            s.ws.write_formula(r, 4, label, fmts.chrome("label_right"))
        else:
            s.merge(r, 4, 5, label,
                    fmts.chrome("total_label" if bold else "label_right"))
        fmt = fmts.calc("money", bold=bold, align="right")
        s.ws.merge_range(r, 6, r, 7, "", fmt)
        s.ws.write_formula(r, 6, _lookup(reg, "Invoices", key, "invoice_no",
                                         input_cell), fmt)
        r += 1
    r += 1
    s.note(r, "Payment terms: payable within the number of days set on the "
              "Settings tab. Please pay to the account below and quote the "
              "invoice number.", last, first_col=0, height=30)
    r += 1
    s.merge(r, 0, last, "", fmts.chrome("label"))
    s.ws.write_formula(r, 0, '="Bank details: "&Biz_Bank',
                       fmts.calc("text", align="left"))
    s.finish(gridlines=False, fit_width=True)
    return s


# ------------------------------------------------------------- pet care
def build_care_sheet(book, fmts, cfg: Config, reg) -> SheetWriter:
    s = SheetWriter(book, fmts, cfg, reg, "Print Pet Care",
                    tab_color=Palette.primary_mid, landscape=False)
    last = 7
    s.set_col(0, 0, 16)
    s.set_col(1, 1, 16)
    s.set_col(2, 3, 16)
    s.set_col(4, 4, 16)
    s.set_col(5, 7, 14)
    s.banner("Pet Care Sheet", "Choose the pet in the cream cell. Print one "
             "sheet per pet and keep it by the lead.", last, nav=False)

    r = 3
    s.merge(r, 0, 1, "Pet reference", fmts.chrome("form_label"))
    first_pet = (f'{sample(cfg).pets[0]["name"]} ({sample(cfg).pets[0]["owner"]})'
                 if cfg.include_sample_data else "")
    s.merge(r, 2, 5, first_pet, fmts.input("text", bold=True))
    input_cell = f"$C${r + 1}"
    r += 2

    s.section(r, "Owner & contacts", last)
    r += 1
    fields_a = [
        ("Owner", "owner"), ("Species", "type"), ("Breed", "breed"),
        ("Age (years)", "age"), ("Weight (kg)", "weight"),
        ("Gender", "gender"),
    ]
    fields_b = [
        ("Vet", "vet_name"), ("Vet phone", "vet_phone"),
        ("Vaccines valid until", "vacc_expiry"), ("Vaccine status", "vacc_status"),
        ("Pet insurer", "insurer"), ("Microchip no.", "microchip"),
    ]
    r = _two_column(s, fmts, reg, r, fields_a, fields_b, input_cell, last)
    r += 1

    s.section(r, "Safety", last)
    r += 1
    safety_a = [("Risk flag", "risk"), ("Temperament", "temperament"),
                ("Allergies", "allergies")]
    safety_b = [("Medical conditions", "medical"), ("Medication", "medication")]
    r = _two_column(s, fmts, reg, r, safety_a, safety_b, input_cell, last)
    r += 1

    s.section(r, "Routine", last)
    r += 1
    for label, key in [("Feeding", "feeding"), ("Walking & exercise", "walking"),
                       ("Grooming", "grooming"),
                       ("Behaviour notes", "behaviour"),
                       ("Handling instructions", "handling")]:
        s.merge(r, 0, 1, label, fmts.chrome("form_label"))
        s.ws.merge_range(r, 2, r, last, "", fmts.calc("wrap", align="left"))
        s.ws.write_formula(r, 2, _lookup(reg, "Pets", key, "label", input_cell),
                           fmts.calc("wrap", align="left"))
        s.row_height(r, 30)
        r += 1

    s.finish(gridlines=False, fit_width=True)
    return s


def _two_column(s, fmts, reg, r, left, right, input_cell, last) -> int:
    count = max(len(left), len(right))
    for i in range(count):
        if i < len(left):
            label, key = left[i]
            _pair(s, fmts, r, label,
                  _lookup(reg, "Pets", key, "label", input_cell),
                  0, 2, 3, style="text")
        if i < len(right):
            label, key = right[i]
            _pair(s, fmts, r, label,
                  _lookup(reg, "Pets", key, "label", input_cell),
                  4, 5, last, style="text")
        r += 1
    return r


# ------------------------------------------------------------ visit report
def build_visit_report(book, fmts, cfg: Config, reg) -> SheetWriter:
    s = SheetWriter(book, fmts, cfg, reg, "Print Visit",
                    tab_color=Palette.primary_mid, landscape=False)
    last = 7
    s.set_col(0, 0, 16)
    s.set_col(1, 1, 16)
    s.set_col(2, 3, 16)
    s.set_col(4, 4, 16)
    s.set_col(5, 7, 14)
    s.banner("Visit Report", "Type a Booking ID in the cream cell. The visit "
             "record prints as proof of care.", last, nav=False)

    r = 3
    s.merge(r, 0, 1, "Booking ID", fmts.chrome("form_label"))
    booking_id = f"{cfg.booking_prefix}0001" if cfg.include_sample_data else ""
    s.merge(r, 2, 5, booking_id, fmts.input("text", bold=True))
    input_cell = f"$C${r + 1}"
    r += 2

    s.section(r, "Booking", last)
    r += 1
    booking_a = [("Client", "client"), ("Pet", "pet"), ("Service", "service")]
    booking_b = [("Date", "date"), ("Scheduled start", "start"),
                 ("Carer", "staff")]
    r = _booking_pairs(s, fmts, reg, r, booking_a, booking_b, input_cell,
                       last, "Bookings", "id")
    r += 1

    s.section(r, "Visit record", last)
    r += 1
    visit_a = [("Arrived", "arrive"), ("Left", "depart"),
               ("Minutes on site", "minutes"), ("Punctuality", "punctual")]
    visit_b = [("Fed", "fed"), ("Fresh water", "water"),
               ("Medication given", "meds"), ("Mood", "mood")]
    r = _booking_pairs(s, fmts, reg, r, visit_a, visit_b, input_cell, last,
                       "Visit Log", "booking")
    r += 1
    for label, key in [("Health observations", "health"),
                       ("Visit notes", "notes")]:
        s.merge(r, 0, 1, label, fmts.chrome("form_label"))
        s.ws.merge_range(r, 2, r, last, "", fmts.calc("wrap", align="left"))
        s.ws.write_formula(r, 2, _visit_lookup(reg, key, input_cell),
                           fmts.calc("wrap", align="left"))
        s.row_height(r, 36)
        r += 1
    r += 1
    s.note(r, "Signed: ____________________________   Date: ______________",
           last, first_col=0, height=28, boxed=False)

    s.finish(gridlines=False, fit_width=True)
    return s


def _visit_lookup(reg, key: str, input_cell: str) -> str:
    return (f'=IFERROR(INDEX({reg.rng("Visit Log", key)},'
            f'MATCH({input_cell},{reg.rng("Visit Log", "booking")},0)),"")')


def _booking_pairs(s, fmts, reg, r, left, right, input_cell, last, sheet,
                   match_key) -> int:
    for i in range(max(len(left), len(right))):
        for side, items, label_col, value_col, value_end in (
                (0, left, 0, 2, 3), (1, right, 4, 5, last)):
            if i >= len(items):
                continue
            label, key = items[i]
            if sheet == "Bookings":
                formula = _lookup(reg, "Bookings", key, "id", input_cell)
            else:
                formula = _visit_lookup(reg, key, input_cell)
            _pair(s, fmts, r, label, formula, label_col, value_col, value_end,
                  style="text")
        r += 1
    return r


# ------------------------------------------------------------- blank forms
def build_forms(book, fmts, cfg: Config, reg) -> SheetWriter:
    s = SheetWriter(book, fmts, cfg, reg, "Print Forms",
                    tab_color=Palette.grey_text, landscape=False)
    last = 7
    s.set_col(0, 0, 18)
    s.set_col(1, last, 14)
    s.banner("Printable Forms", "Blank forms to print and keep on file. Fill "
             "them in by hand or type into the boxes.", last, nav=False)

    r = 3
    r = _form_intake(s, fmts, cfg, r, last)
    r += 2
    r = _form_key(s, fmts, r, last)
    r += 2
    r = _form_medication(s, fmts, r, last)
    r += 2
    _form_vet_authority(s, fmts, cfg, r, last)

    s.finish(gridlines=False, fit_width=True)
    return s


def _lines(s, fmts, r, labels, last, height=24):
    for label in labels:
        s.merge(r, 0, 1, label, fmts.chrome("form_label"))
        s.ws.merge_range(r, 2, r, last, "", fmts.chrome("form_line"))
        s.row_height(r, height)
        r += 1
    return r


def _form_intake(s, fmts, cfg, r, last) -> int:
    s.section(r, "Client intake & consent", last)
    r += 1
    r = _lines(s, fmts, r, [
        "Client name", "Address", "Phone / email", "Emergency contact",
        "Preferred contact method", "Key / access arrangement",
    ], last)
    s.section(r, "Pet details (one line per pet)", last)
    r += 1
    for i in range(3):
        s.merge(r, 0, 0, f"Pet {i + 1}", fmts.chrome("form_label"))
        for c in range(1, last + 1):
            s.ws.write_blank(r, c, None, fmts.chrome("form_line"))
        s.row_height(r, 24)
        r += 1
    s.note(r, "I agree to the care terms, authorise emergency vet treatment up "
              "to the amount set out in my agreement, and confirm the "
              "information above is correct.",
           last, first_col=0, height=34)
    r += 1
    return _lines(s, fmts, r, ["Client signature", "Date"], last, height=28)


def _form_key(s, fmts, r, last) -> int:
    s.section(r, "Key & access receipt", last)
    r += 1
    r = _lines(s, fmts, r, [
        "Client name", "Pet / property", "Key or code description",
        "Date received", "Received by", "Date returned",
        "Returned by", "Notes",
    ], last)
    return r


def _form_medication(s, fmts, r, last) -> int:
    s.section(r, "Medication administration log", last)
    r += 1
    heads = ["Date", "Time given", "Pet", "Medication", "Dose",
             "Given by", "Initials"]
    for i, head in enumerate(heads):
        s.write(r, i, head, fmts.chrome("header"))
    s.row_height(r, 22)
    r += 1
    for _ in range(10):
        for c in range(0, len(heads)):
            s.ws.write_blank(r, c, None, fmts.chrome("form_line"))
        s.row_height(r, 22)
        r += 1
    return r


def _form_vet_authority(s, fmts, cfg, r, last) -> int:
    s.section(r, "Emergency veterinary authority", last)
    r += 1
    s.note(r, "I authorise the carer to take my pet to the vet listed below and "
              "approve treatment costs up to the limit shown. I understand I "
              "remain responsible for the bill.",
           last, first_col=0, height=40)
    r += 1
    return _lines(s, fmts, r, [
        "Pet name", "Preferred vet", "Vet phone", "Spending limit",
        "Owner signature", "Date",
    ], last, height=28)
