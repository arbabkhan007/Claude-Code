"""`Payments` - money received, tips, refunds and reconciliation."""

from __future__ import annotations

from ..config import Config, Palette
from ..layout import Col, SheetSpec
from ..sample_data import get as sample
from ..writer import date_check, list_from, number_check, yes_no
from .common import alert_cf, blank, id_col, month_col, status_cf

NAME = "Payments"


def spec(cfg: Config) -> SheetSpec:
    columns = [
        id_col("amount", '"PM-"', header="Payment ID", width=11),
        Col("date", "Date received", 12, "date", validate=date_check()),
        Col("client", "Client", 20, "text",
            validate=list_from("ClientNames")),
        Col("invoice_no", "Invoice no.", 12, "text",
            validate=list_from("InvoiceNos")),
        Col("amount", "Amount paid", 12, "money",
            validate=number_check(0, 1000000)),
        Col("tip", "Tip", 9, "money", validate=number_check(0, 100000)),
        Col("refund", "Refund", 10, "money",
            validate=number_check(0, 1000000)),
        Col("net", "Net to invoice", 12, "money",
            formula=blank("amount",
                          'ROUND({amount}{r}-IF({refund}{r}="",0,{refund}{r}),2)')),
        Col("received", "Total received", 12, "money",
            formula=blank("amount",
                          'ROUND({net}{r}+IF({tip}{r}="",0,{tip}{r}),2)')),
        Col("method", "Payment method", 16, "text",
            validate=list_from("PaymentMethodList")),
        Col("reference", "Reference", 14, "text"),
        Col("deposit", "Deposit?", 9, "flag", validate=yes_no(),
            cf=status_cf()),
        Col("confirmed", "Confirmed", 10, "flag", validate=yes_no(),
            cf=status_cf()),
        Col("reconciled", "Reconciled", 10, "flag", validate=yes_no(),
            cf=status_cf()),
        Col("notes", "Notes", 28, "wrap"),
        month_col("date"),
        Col("alert", "Action needed", 26, "status",
            formula=blank(
                "amount",
                'IF({invoice_no}{r}="","Action - link to an invoice",'
                'IF({confirmed}{r}<>"Yes","Action - confirm receipt",'
                'IF({reconciled}{r}<>"Yes","Action - reconcile with bank",'
                '"OK")))'),
            cf=alert_cf()),
    ]

    return SheetSpec(
        name=NAME,
        title="Payments Received",
        subtitle="Every payment, tip and refund. Net and total figures feed "
                 "the invoices, client balances and monthly reports.",
        columns=columns,
        rows=cfg.row_count(NAME),
        tab_color=Palette.good_text,
        freeze_cols=2,
        samples=sample(cfg).payments,
        help_text="Choose the invoice and the amount. Net and total received "
                  "calculate themselves - tips count towards income but not "
                  "towards the invoice.",
    )
