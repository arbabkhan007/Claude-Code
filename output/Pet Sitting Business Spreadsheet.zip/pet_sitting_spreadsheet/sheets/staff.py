"""`Staff` - carers, their certificates, pay and workload."""

from __future__ import annotations

from ..config import Config, Palette
from ..layout import Col, SheetSpec
from ..sample_data import get as sample
from ..writer import date_check, list_from, number_check
from .common import alert_cf, blank, status_cf

NAME = "Staff"


def spec(cfg: Config) -> SheetSpec:
    columns = [
        Col("name", "Name", 18, "text",
            note="This name is used by every Assigned to / Carer drop down."),
        Col("role", "Role", 14, "text", validate=list_from("StaffRoleList")),
        Col("phone", "Phone", 17, "text"),
        Col("email", "Email", 26, "text"),
        Col("employment", "Employment", 20, "text",
            validate=list_from("EmploymentTypeList")),
        Col("start_date", "Start date", 12, "date", validate=date_check()),
        Col("status", "Status", 11, "status",
            validate=list_from("StaffStatusList"),
            cf=[{"type": "text", "criteria": "containing", "value": "Active",
                 "fmt": "good"},
                {"type": "text", "criteria": "containing",
                 "value": "Inactive", "fmt": "muted"}]),
        Col("pay_type", "Pay basis", 13, "text",
            validate=list_from("PayTypeList")),
        Col("pay_rate", "Pay rate", 11, "money",
            validate=number_check(0, 100000)),
        Col("cert", "Certificates held", 26, "wrap"),
        Col("cert_expiry", "Certificate expires", 12, "date",
            validate=date_check()),
        Col("cert_status", "Certificate status", 15, "status",
            formula=blank("name",
                          'IF({cert_expiry}{r}="","No certificate on file",'
                          'IF({cert_expiry}{r}<TODAY(),"Expired",'
                          'IF({cert_expiry}{r}-TODAY()<=ExpiryAlertDays,'
                          '"Due soon","Valid")))'),
            cf=alert_cf()),
        Col("availability", "Availability", 20, "text"),
        Col("jobs_done", "Completed bookings", 11, "int",
            formula=blank("name",
                          'COUNTIFS([[Bookings.staff]],{name}{r},'
                          '[[Bookings.status]],"Completed")')),
        Col("hours_worked", "Hours on bookings", 11, "number1",
            formula=blank("name",
                          'ROUND(SUMIFS([[Bookings.hours]],[[Bookings.staff]],'
                          '{name}{r},[[Bookings.status]],"Completed"),1)')),
        Col("notes", "Notes", 30, "wrap"),
        Col("alert", "Action needed", 26, "status",
            formula=blank(
                "name",
                'IF({cert_status}{r}="Expired","Action - renew certificate",'
                'IF({status}{r}<>"Active","Not active",'
                'IF({cert_status}{r}="Due soon","Action - renewal due soon",'
                '"OK")))'),
            cf=alert_cf()),
    ]

    return SheetSpec(
        name=NAME,
        title="Staff, Certificates & Pay",
        subtitle="Your team, their qualifications and how much work each person "
                 "has done.",
        columns=columns,
        rows=cfg.row_count(NAME),
        tab_color=Palette.primary,
        freeze_cols=1,
        samples=sample(cfg).staff,
        help_text="Keep certificate expiry dates up to date - the alert column "
                  "warns you before anyone works with an expired qualification.",
    )
