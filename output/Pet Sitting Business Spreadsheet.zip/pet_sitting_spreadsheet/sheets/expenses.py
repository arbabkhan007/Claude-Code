"""`Expenses` - business costs, with business use % and personal spend split out."""

from __future__ import annotations

from ..config import Config, Palette
from ..layout import Col, SheetSpec
from ..sample_data import get as sample
from ..writer import date_check, list_from, number_check, yes_no
from .common import alert_cf, blank, id_col, month_col, status_cf

NAME = "Expenses"


def spec(cfg: Config) -> SheetSpec:
    columns = [
        id_col("description", '"EX-"', header="Expense ID", width=11),
        Col("date", "Date", 12, "date", validate=date_check()),
        Col("category", "Category", 22, "text",
            validate=list_from("ExpenseCategoryList")),
        Col("description", "Description", 32, "wrap"),
        Col("supplier", "Supplier / payee", 20, "text"),
        Col("amount", "Amount", 12, "money",
            validate=number_check(0, 1000000)),
        Col("method", "Paid by", 16, "text",
            validate=list_from("PaymentMethodList")),
        Col("type", "Business / personal", 13, "text",
            validate=list_from("BusinessPersonalList"), cf=status_cf()),
        Col("business_pct", "Business use %", 10, "percent",
            validate=number_check(0, 1),
            note="Share of the cost used for the business. Blank = 100%."),
        Col("business_amt", "Business amount", 13, "money",
            formula=blank("amount",
                          'IF({type}{r}="Personal",0,ROUND({amount}{r}*'
                          'IF({business_pct}{r}="",1,{business_pct}{r}),2))'),
            cf=[{"type": "data_bar", "bar_color": "#E2A33C"}]),
        Col("recurring", "Recurring", 12, "text",
            validate=list_from("RecurringExpenseList")),
        Col("receipt", "Receipt kept?", 10, "flag", validate=yes_no(),
            cf=status_cf()),
        Col("approval", "Approval", 12, "status",
            validate=list_from("ExpenseApprovalList"), cf=status_cf()),
        Col("notes", "Notes", 28, "wrap"),
        month_col("date"),
        Col("alert", "Action needed", 24, "status",
            formula=blank(
                "amount",
                'IF({approval}{r}="Pending","Action - approve or reject",'
                'IF({receipt}{r}<>"Yes","Action - keep the receipt",'
                '"OK"))'),
            cf=alert_cf()),
    ]

    return SheetSpec(
        name=NAME,
        title="Business Expenses",
        subtitle="Every business cost in one place. Personal spend is kept "
                 "for your records but left out of profit and tax figures.",
        columns=columns,
        rows=cfg.row_count(NAME),
        tab_color=Palette.bad_text,
        freeze_cols=2,
        samples=sample(cfg).expenses,
        help_text="Choose a category and enter the amount. Use Business use % "
                  "for mixed costs such as a phone or broadband bill.",
    )
