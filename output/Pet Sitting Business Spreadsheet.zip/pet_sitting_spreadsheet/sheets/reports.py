"""`Reports` - monthly summary, service performance, expense categories, clients."""

from __future__ import annotations

from ..config import Config, Palette
from ..writer import SheetWriter

SHEET = "Reports"
LAST_COL = 7


def build(book, fmts, cfg: Config, reg) -> SheetWriter:
    s = SheetWriter(book, fmts, cfg, reg, SHEET, tab_color=Palette.accent)
    s.set_col(0, 0, 24)
    s.set_col(1, LAST_COL, 15)
    s.banner("Reports",
             "Month by month, service by service and category by category. "
             "Everything here is calculated - nothing to type.", LAST_COL)

    money = fmts.calc("money")
    money_bold = fmts.calc("money", bold=True)
    count = fmts.calc("int")
    text = fmts.calc("text")

    # ---- 1. month by month ----------------------------------------------
    r = s.section(3, "1. Month by month (financial year)", LAST_COL)
    heads = ["Month", "Bookings", "Booked value", "Invoiced", "Received",
             "Costs", "Profit (cash)"]
    r = s.table_head(r, 0, heads)
    first_month = r
    for i in range(12):
        calc_row = reg[("Calc")].first_data_row + i
        s.ws.write_formula(r, 0, f"={reg.cell('Calc', 'label', calc_row)}", text)
        keys = ["bookings", "booked_value", "invoiced", "received", "costs",
                "profit"]
        for j, key in enumerate(keys):
            fmt = count if key == "bookings" else money
            s.ws.write_formula(r, 1 + j, f"={reg.cell('Calc', key, calc_row)}",
                               fmt)
        r += 1
    s.ws.write(r, 0, "Financial year total", fmts.chrome("total_label"))
    for j in range(1, 7):
        col = j
        letter = chr(ord("A") + col)
        fmt = fmts.chrome("total_value", num_format=(
            "#,##0" if j == 1 else cfg.money_format))
        s.ws.write_formula(r, col, f"=SUM({letter}{first_month + 1}:"
                                   f"{letter}{first_month + 12})", fmt)
    r += 2

    # ---- 2. services ------------------------------------------------------
    r = s.section(r, "2. Service performance (top 10 services)", LAST_COL)
    r = s.table_head(r, 0, ["Service", "Bookings", "Revenue", "Average value",
                            "Share of revenue"])
    svc_first = r
    total_rev_cell = None
    svc_name = reg.rng("Bookings", "service")
    svc_status = reg.rng("Bookings", "status")
    svc_total = reg.rng("Bookings", "total")
    for i in range(10):
        s.ws.write_formula(r, 0, f'=IFERROR(INDEX(ServiceNames,{i + 1}),"")',
                           text)
        s.ws.write_formula(
            r, 1,
            f'=IF(A{r + 1}="","",COUNTIFS({svc_name},A{r + 1},'
            f'{svc_status},"<>Cancelled"))',
            count)
        s.ws.write_formula(
            r, 2,
            f'=IF(A{r + 1}="","",SUMIFS({svc_total},{svc_name},A{r + 1},'
            f'{svc_status},"<>Cancelled"))', money)
        s.ws.write_formula(
            r, 3, f'=IF(OR(A{r + 1}="",N(B{r + 1})=0),"",C{r + 1}/B{r + 1})',
            money)
        r += 1
    svc_last = r - 1
    for rr in range(svc_first, svc_last + 1):
        s.ws.write_formula(
            rr, 4,
            f'=IF(OR(A{rr + 1}="",N(C{rr + 1})=0),"",'
            f'C{rr + 1}/SUM($C${svc_first + 1}:$C${svc_last + 1}))',
            fmts.calc("percent"))
    r += 1

    # ---- 3. expenses by category ----------------------------------------
    r = s.section(r, "3. Business expenses by category", LAST_COL)
    r = s.table_head(r, 0, ["Category", "Business amount", "Share"])
    exp_first = r
    for i in range(20):
        s.ws.write_formula(r, 0, f'=IFERROR(INDEX(ExpenseCategoryList,{i + 1}),"")',
                           text)
        s.ws.write_formula(
            r, 1,
            f'=IF(A{r + 1}="","",SUMIFS({reg.rng("Expenses", "business_amt")},'
            f'{reg.rng("Expenses", "category")},A{r + 1}))', money)
        r += 1
    exp_last = r - 1
    for rr in range(exp_first, exp_last + 1):
        s.ws.write_formula(
            rr, 2,
            f'=IF(OR(A{rr + 1}="",N(B{rr + 1})=0),"",B{rr + 1}/'
            f'SUM($B${exp_first + 1}:$B${exp_last + 1}))',
            fmts.calc("percent"))
    s.ws.write(r, 0, "Total business expenses", fmts.chrome("total_label"))
    s.ws.write_formula(r, 1, f"=SUM(B{exp_first + 1}:B{exp_last + 1})",
                       fmts.chrome("total_value", num_format=cfg.money_format))
    r += 2

    # ---- 4. clients by status ---------------------------------------------
    r = s.section(r, "4. Clients by status", LAST_COL)
    r = s.table_head(r, 0, ["Status", "Clients", "Lifetime revenue"])
    for i in range(5):
        s.ws.write_formula(r, 0, f'=IFERROR(INDEX(ClientStatusList,{i + 1}),"")',
                           text)
        s.ws.write_formula(
            r, 1,
            f'=IF(A{r + 1}="","",COUNTIF({reg.rng("Clients", "status")},A{r + 1}))',
            count)
        s.ws.write_formula(
            r, 2,
            f'=IF(A{r + 1}="","",SUMIFS({reg.rng("Clients", "revenue")},'
            f'{reg.rng("Clients", "status")},A{r + 1}))', money)
        r += 1
    r += 1

    # ---- 5. year to date --------------------------------------------------
    r = s.section(r, "5. Year to date", LAST_COL)
    calc_m = reg.rng("Calc", "m_start")
    months_to_date = f'COUNTIFS({calc_m},"<="&TODAY())'
    received = f'SUMIFS({reg.rng("Calc", "received")},{calc_m},"<="&TODAY())'
    ytd = [
        ("Received", f"={received}", money_bold),
        ("Costs",
         f'=SUMIFS({reg.rng("Calc", "costs")},{calc_m},"<="&TODAY())',
         money_bold),
        ("Profit (cash)",
         f'=SUMIFS({reg.rng("Calc", "profit")},{calc_m},"<="&TODAY())',
         money_bold),
        ("Average income per month", f"=IFERROR({received}/MAX(1,"
         f"{months_to_date}),0)", money),
    ]
    for label, formula, fmt in ytd:
        s.merge(r, 0, 0, label, fmts.chrome("label_bold"))
        s.ws.write_formula(r, 1, formula, fmt)
        r += 1

    s.finish(freeze_row=None, gridlines=False)
    return s
