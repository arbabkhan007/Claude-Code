"""`Visit Log` - proof of service: one row per visit, walk or overnight."""

from __future__ import annotations

from ..config import Config, Palette
from ..layout import Col, SheetSpec
from ..sample_data import get as sample
from ..writer import date_check, list_from, number_check, yes_no
from .common import alert_cf, blank, id_col, month_col, status_cf

NAME = "Visit Log"


def _bk(field: str, fallback: str = '""') -> str:
    return (f'IFERROR(INDEX([[Bookings.{field}]],'
            f'MATCH({{booking}}{{r}},[[Bookings.id]],0)),{fallback})')


def spec(cfg: Config) -> SheetSpec:
    columns = [
        id_col("booking", '"VS-"', header="Visit ID", width=11),
        Col("booking", "Booking ID", 12, "text",
            validate=list_from("BookingIDs"),
            note="Pick the booking. Client, pet, service and scheduled time "
                 "fill in automatically."),
        Col("client", "Client", 20, "text",
            formula=blank("booking", _bk("client"))),
        Col("pet", "Pet", 24, "text",
            formula=blank("booking", _bk("pet"))),
        Col("service", "Service", 22, "text",
            formula=blank("booking", _bk("service"))),
        Col("staff", "Carer", 15, "text",
            formula=blank("booking", _bk("staff"))),
        Col("date", "Visit date", 12, "date",
            formula=blank("booking", _bk("date"))),
        Col("sched_start", "Scheduled start", 10, "time",
            formula=blank("booking", _bk("start"))),
        Col("arrive", "Arrived", 9, "time"),
        Col("depart", "Left", 9, "time"),
        Col("minutes", "Minutes on site", 10, "int",
            formula='=IF(OR({arrive}{r}="",{depart}{r}=""),"",'
                    'ROUND(({depart}{r}-{arrive}{r}+'
                    'IF({depart}{r}<{arrive}{r},1,0))*1440,0))'),
        Col("punctual", "Punctuality", 14, "status",
            formula='=IF(OR({arrive}{r}="",{sched_start}{r}=""),"",'
                    'IF({arrive}{r}<={sched_start}{r}+TIME(0,10,0),"On time",'
                    '"Late "&TEXT(({arrive}{r}-{sched_start}{r})*1440,"0")'
                    '&" min"))',
            cf=[{"type": "text", "criteria": "containing",
                 "value": "On time", "fmt": "good"},
                {"type": "text", "criteria": "containing",
                 "value": "Late", "fmt": "warn"}]),
        Col("fed", "Fed", 8, "flag", validate=list_from("YesNoNAList"),
            cf=status_cf()),
        Col("water", "Fresh water", 9, "flag", validate=list_from(
            "YesNoNAList"), cf=status_cf()),
        Col("meds", "Medication given", 10, "flag",
            validate=list_from("YesNoNAList"), cf=status_cf()),
        Col("potty", "Potty / litter", 14, "text",
            validate=list_from("PottyList")),
        Col("mood", "Mood", 12, "text", validate=list_from("MoodList"),
            cf=[{"type": "text", "criteria": "containing",
                 "value": "Unwell", "fmt": "bad"},
                {"type": "text", "criteria": "containing",
                 "value": "Anxious", "fmt": "warn"},
                {"type": "text", "criteria": "containing",
                 "value": "Aggressive", "fmt": "bad"}]),
        Col("appetite", "Appetite", 12, "text",
            validate=list_from("AppetiteList"),
            cf=[{"type": "text", "criteria": "containing",
                 "value": "None", "fmt": "bad"},
                {"type": "text", "criteria": "containing",
                 "value": "Reduced", "fmt": "warn"}]),
        Col("health", "Health observations", 28, "wrap"),
        Col("incident", "Incident?", 9, "flag", validate=yes_no(),
            cf=[{"type": "text", "criteria": "containing", "value": "Yes",
                 "fmt": "bad"}]),
        Col("incident_ref", "Incident ref", 11, "text"),
        Col("update_sent", "Client updated", 10, "flag", validate=yes_no(),
            cf=status_cf()),
        Col("status", "Visit status", 16, "status",
            validate=list_from("VisitStatusList"), cf=status_cf()),
        Col("notes", "Visit notes", 34, "wrap"),
        month_col("date"),
        # Numeric copy of the visit date (0 when empty) so the Pets and
        # Clients summaries can multiply it inside SUMPRODUCT safely.
        Col("date_num", "Visit date (number)", 10, "int", hidden=True,
            formula='=IF({date}{r}="",0,{date}{r})'),
        Col("alert", "Action needed", 26, "status",
            formula=blank(
                "booking",
                'IF({status}{r}="Missed","Missed visit - contact client",'
                'IF({incident}{r}="Yes","Incident - follow up",'
                'IF(AND({status}{r}="Completed",{update_sent}{r}<>"Yes"),'
                '"Action - send client update",'
                'IF(AND({status}{r}="Scheduled",{date}{r}<TODAY()),'
                '"Overdue - log the result","OK"))))'),
            cf=alert_cf()),
    ]

    return SheetSpec(
        name=NAME,
        title="Daily Visit & Pet Care Log",
        subtitle="Proof of service for every walk, drop-in and overnight stay: "
                 "times, care given, mood, health notes and client updates.",
        columns=columns,
        rows=cfg.row_count(NAME),
        tab_color=Palette.accent,
        freeze_cols=3,
        samples=sample(cfg).visits,
        help_text="Start with the Booking ID - everything else about the "
                  "visit fills in automatically. Minutes on site and "
                  "punctuality are calculated.",
    )
