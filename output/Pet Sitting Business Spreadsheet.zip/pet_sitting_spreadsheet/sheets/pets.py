"""`Pets` - one row per animal: routine, medical, vaccination and safety notes."""

from __future__ import annotations

from ..config import Config, Palette
from ..layout import Col, SheetSpec
from ..sample_data import get as sample
from ..writer import date_check, list_from, number_check
from .common import alert_cf, blank, status_cf

NAME = "Pets"


def spec(cfg: Config) -> SheetSpec:
    visit_done = ('COUNTIFS([[Visit Log.pet]],{label}{r},'
                  '[[Visit Log.status]],"Completed")')
    last_visit = ('SUMPRODUCT(MAX(([[Visit Log.pet]]={label}{r})'
                  '*([[Visit Log.status]]="Completed")*[[Visit Log.date_num]]))')

    columns = [
        Col("name", "Pet name", 14, "text",
            note="Pick the owner from the drop down first so bookings and "
                 "visits can find this pet."),
        Col("owner", "Owner (client)", 20, "text",
            validate=list_from("ClientNames")),
        Col("label", "Pet reference", 26, "text",
            formula=blank("name",
                          '{name}{r}&" ("&{owner}{r}&")"'),
            note="Used by the Bookings, Visit Log and Health Log drop downs. "
                 "Calculated - do not type here."),
        Col("type", "Species", 11, "text", validate=list_from("PetTypeList")),
        Col("breed", "Breed", 20, "text"),
        Col("dob", "Date of birth", 12, "date", validate=date_check()),
        Col("age", "Age (years)", 9, "number1",
            formula=blank("dob", 'ROUND(YEARFRAC({dob}{r},TODAY()),1)')),
        Col("gender", "Gender", 14, "text",
            validate=list_from("PetGenderList")),
        Col("weight", "Weight (kg)", 10, "number1",
            validate=number_check(0, 200)),
        Col("colour", "Colour & markings", 18, "text"),
        Col("microchip", "Microchip no.", 16, "text"),
        Col("temperament", "Temperament", 16, "text",
            validate=list_from("TemperamentList")),
        Col("behaviour", "Behaviour notes", 26, "wrap"),
        Col("allergies", "Allergies", 18, "wrap"),
        Col("medical", "Medical conditions", 28, "wrap"),
        Col("vet_name", "Veterinarian", 22, "text"),
        Col("vet_phone", "Vet phone", 16, "text"),
        Col("vacc_expiry", "Vaccinations valid until", 14, "date",
            validate=date_check()),
        Col("vacc_status", "Vaccination status", 14, "status",
            formula=blank("vacc_expiry",
                          'IF({vacc_expiry}{r}<TODAY(),"Expired",'
                          'IF({vacc_expiry}{r}-TODAY()<=VaccAlertDays,'
                          '"Due soon","Valid"))'),
            cf=[{"type": "text", "criteria": "containing",
                 "value": "Expired", "fmt": "bad"},
                {"type": "text", "criteria": "containing",
                 "value": "Due soon", "fmt": "warn"},
                {"type": "text", "criteria": "containing",
                 "value": "Valid", "fmt": "good"}]),
        Col("insurer", "Pet insurer", 18, "text"),
        Col("feeding", "Feeding instructions", 28, "wrap"),
        Col("medication", "Medication", 18, "text"),
        Col("walking", "Walking & exercise", 24, "wrap"),
        Col("grooming", "Grooming", 18, "wrap"),
        Col("risk", "Risk flag", 16, "status",
            validate=list_from("RiskFlagList"),
            cf=[{"type": "text", "criteria": "not containing",
                 "value": "None", "fmt": "warn"}]),
        Col("handling", "Handling instructions", 30, "wrap"),
        Col("visits", "Completed visits", 10, "int",
            formula=blank("label", visit_done)),
        Col("last_visit", "Last visit", 12, "date",
            formula=blank("label",
                          f'IF({last_visit}=0,"",{last_visit})')),
        Col("alert", "Action needed", 28, "status",
            formula=blank(
                "name",
                'IF({vacc_status}{r}="Expired","Action - vaccination expired",'
                'IF(AND({risk}{r}<>"",{risk}{r}<>"None"),'
                '"Risk - read handling notes",'
                'IF({medication}{r}<>"None",'
                'IF({medication}{r}="","OK","Medication - see health log"),'
                '"OK")))'),
            cf=alert_cf() + [
                {"type": "text", "criteria": "containing",
                 "value": "Risk", "fmt": "bold_bad"},
                {"type": "text", "criteria": "containing",
                 "value": "Medication", "fmt": "warn"}]),
    ]

    return SheetSpec(
        name=NAME,
        title="Pet Profiles",
        subtitle="Everything a carer needs before the lead comes off the "
                 "hook: routine, medical, vaccination status and safety "
                 "warnings for every animal.",
        columns=columns,
        rows=cfg.row_count(NAME),
        tab_color=Palette.primary,
        freeze_cols=2,
        samples=sample(cfg).pets,
        help_text="Start with the owner. The grey 'Pet reference' column is "
                  "what bookings and logs use, so two pets with the same "
                  "name never get mixed up.",
    )
