"""`Incidents` - the incident report register for bites, escapes and injuries."""

from __future__ import annotations

from ..config import Config, Palette
from ..layout import Col, SheetSpec
from ..sample_data import get as sample
from ..writer import date_check, list_from, number_check, yes_no
from .common import alert_cf, blank, id_col, month_col, status_cf

NAME = "Incidents"


def spec(cfg: Config) -> SheetSpec:
    columns = [
        id_col("client", '"IN-"', digits=3, header="Incident ID", width=12,
               note="Generated from the row number. Keep a record of every "
                    "incident - even minor ones."),
        Col("date", "Date", 12, "date", validate=date_check()),
        Col("time", "Time", 9, "time"),
        Col("client", "Client", 20, "text",
            validate=list_from("ClientNames")),
        Col("pet", "Pet", 22, "text", validate=list_from("PetLabels")),
        Col("reported_by", "Reported by", 15, "text",
            validate=list_from("StaffNames")),
        Col("booking", "Booking ID", 12, "text",
            validate=list_from("BookingIDs")),
        Col("type", "Incident type", 17, "text",
            validate=list_from("IncidentTypeList")),
        Col("severity", "Severity", 11, "status",
            validate=list_from("SeverityList"),
            cf=[{"type": "text", "criteria": "containing",
                 "value": "Critical", "fmt": "bold_bad"},
                {"type": "text", "criteria": "containing", "value": "High",
                 "fmt": "bad"},
                {"type": "text", "criteria": "containing",
                 "value": "Medium", "fmt": "warn"},
                {"type": "text", "criteria": "containing", "value": "Low",
                 "fmt": "good"}]),
        Col("description", "What happened", 40, "wrap"),
        Col("action", "Action taken", 36, "wrap"),
        Col("vet_contacted", "Vet contacted", 10, "flag", validate=yes_no(),
            cf=status_cf()),
        Col("owner_notified", "Owner told", 10, "flag", validate=yes_no(),
            cf=status_cf()),
        Col("follow_up_due", "Follow-up due", 12, "date",
            validate=date_check()),
        Col("status", "Status", 13, "status",
            validate=list_from("IncidentStatusList"), cf=status_cf()),
        Col("cost", "Cost", 11, "money", validate=number_check(0, 100000)),
        Col("claim", "Insurance claim?", 10, "flag", validate=yes_no()),
        Col("days_open", "Days open", 9, "int",
            formula=blank("date",
                          'IF(OR({status}{r}="Resolved",{status}{r}="Closed"),'
                          '"",TODAY()-{date}{r})')),
        Col("notes", "Notes & outcome", 30, "wrap"),
        month_col("date"),
        Col("alert", "Action needed", 26, "status",
            formula=blank(
                "client",
                'IF({owner_notified}{r}<>"Yes","Action - tell the owner",'
                'IF(AND({status}{r}<>"Resolved",{status}{r}<>"Closed",'
                '{follow_up_due}{r}<>"",{follow_up_due}{r}<TODAY()),'
                '"Overdue follow-up",'
                'IF(OR({status}{r}="Open",{status}{r}="In progress"),'
                '"Open - keep working it","OK")))'),
            cf=alert_cf()),
    ]

    return SheetSpec(
        name=NAME,
        title="Incident Reports",
        subtitle="A dated register of every incident, what was done, who was "
                 "told and what still needs following up.",
        columns=columns,
        rows=cfg.row_count(NAME),
        tab_color=Palette.bad_text,
        freeze_cols=3,
        samples=sample(cfg).incidents,
        help_text="Record what happened, what you did, who you told and when. "
                  "Keep the owner and the vet informed - the alert column "
                  "chases anything still open.",
    )
