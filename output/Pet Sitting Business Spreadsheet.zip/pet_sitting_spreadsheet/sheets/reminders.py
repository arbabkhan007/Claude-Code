"""`Reminders` - the reminder centre: tasks and deadlines for the business."""

from __future__ import annotations

from ..config import Config, Palette
from ..layout import Col, SheetSpec
from ..sample_data import get as sample
from ..writer import date_check, list_from
from .common import alert_cf, blank, id_col, status_cf

NAME = "Reminders"


def spec(cfg: Config) -> SheetSpec:
    columns = [
        id_col("task", '"RM-"', header="Task ID", width=10),
        Col("task", "Task / reminder", 36, "wrap"),
        Col("category", "Category", 14, "text"),
        Col("due", "Due date", 12, "date", validate=date_check()),
        Col("days_left", "Days left", 9, "int",
            formula=blank("due", '{due}{r}-TODAY()'),
            cf=[{"type": "cell", "criteria": "<", "value": 0,
                 "fmt": "bad"},
                {"type": "cell", "criteria": "between", "minimum": 0,
                 "maximum": "=ReminderLeadDays", "fmt": "warn"}]),
        Col("owner", "Owner", 15, "text", validate=list_from("StaffNames")),
        Col("priority", "Priority", 11, "status",
            validate=list_from("PriorityList"),
            cf=[{"type": "text", "criteria": "containing", "value": "Urgent",
                 "fmt": "bold_bad"},
                {"type": "text", "criteria": "containing", "value": "High",
                 "fmt": "bad"},
                {"type": "text", "criteria": "containing", "value": "Medium",
                 "fmt": "warn"}]),
        Col("status", "Status", 13, "status",
            validate=list_from("TaskStatusList"), cf=status_cf()),
        Col("notes", "Notes", 30, "wrap"),
        Col("alert", "Action needed", 22, "status",
            formula=blank(
                "task",
                'IF({status}{r}="Done","Done",'
                'IF({due}{r}<TODAY(),"Overdue",'
                'IF({due}{r}-TODAY()<=ReminderLeadDays,"Due soon","OK")))'),
            cf=alert_cf() + [{"type": "text", "criteria": "containing",
                              "value": "Done", "fmt": "good"}]),
    ]

    return SheetSpec(
        name=NAME,
        title="Reminder Centre",
        subtitle="Everything with a deadline - invoices to send, certificates "
                 "to renew, stock to order, win-back calls to make.",
        columns=columns,
        rows=cfg.row_count(NAME),
        tab_color=Palette.accent,
        freeze_cols=2,
        samples=sample(cfg).reminders,
        help_text="Add a reminder with its due date and owner. Anything due "
                  "soon or overdue is highlighted and shows on the Dashboard.",
    )
