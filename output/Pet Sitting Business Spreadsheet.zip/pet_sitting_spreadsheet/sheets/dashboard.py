"""`Dashboard` - the one page view: money, bookings, and what needs attention."""

from __future__ import annotations

from ..config import Config, Palette
from ..writer import SheetWriter

SHEET = "Dashboard"
LAST_COL = 11


def build(book, fmts, cfg: Config, reg) -> SheetWriter:
    s = SheetWriter(book, fmts, cfg, reg, SHEET, tab_color=Palette.accent)
    s.set_col(0, LAST_COL, 13)
    s.banner("Business Dashboard",
             "Today's position at a glance - bookings, money in and out, and "
             "everything that needs your attention.", LAST_COL)

    this_month = "MONTH(TODAY())"
    row1 = [
        ("Active clients", 'COUNTIF([[Clients.status]],"Active")', "int",
         "clients marked Active"),
        ("Bookings this month", f"INDEX([[Calc.bookings]],{this_month})",
         "int", "not cancelled"),
        ("Received this month", f"INDEX([[Calc.received]],{this_month})",
         "money0", "payments received"),
        ("Costs this month", f"INDEX([[Calc.costs]],{this_month})",
         "money0", "expenses + mileage"),
        ("Outstanding balance",
         'SUMIFS([[Invoices.balance]],[[Invoices.status]],"<>Draft",'
         '[[Invoices.status]],"<>Cancelled")', "money0", "owed by clients"),
        ("Overdue invoices", 'COUNTIF([[Invoices.pay_status]],"Overdue*")',
         "int", "past their due date"),
    ]
    row2 = [
        ("Bookings next 7 days",
         'COUNTIFS([[Bookings.date]],">="&TODAY(),[[Bookings.date]],"<="&'
         'TODAY()+7,[[Bookings.status]],"<>Cancelled")', "int",
         "coming up this week"),
        ("Booked value this month", f"INDEX([[Calc.booked_value]],{this_month})",
         "money0", "value of this month's bookings"),
        ("Profit this month", f"INDEX([[Calc.profit]],{this_month})",
         "money0", "cash received less costs"),
        ("Profit to date",
         'SUMIFS([[Calc.profit]],[[Calc.m_start]],"<="&TODAY())', "money0",
         "year to date"),
        ("Vaccinations due",
         'COUNTIF([[Pets.vacc_status]],"Expired")+'
         'COUNTIF([[Pets.vacc_status]],"Due soon")', "int",
         "expired or due soon"),
        ("Open incidents",
         'COUNTIF([[Incidents.status]],"Open")+'
         'COUNTIF([[Incidents.status]],"In progress")', "int",
         "not yet resolved"),
    ]

    r = 3
    for i, (label, formula, style, note) in enumerate(row1):
        s.kpi(r, i * 2, label, formula, style, span=2, note=note)
    r += 3 + 1
    for i, (label, formula, style, note) in enumerate(row2):
        s.kpi(r, i * 2, label, formula, style, span=2, note=note)
    r += 3 + 1

    # ---- attention list ---------------------------------------------------
    r = s.section(r, "Needs your attention", LAST_COL)
    s.row_height(r, 18)
    s.merge(r, 0, 5, "Item", fmts.chrome("header_left"))
    s.merge(r, 6, 7, "Count", fmts.chrome("header"))
    s.merge(r, 8, LAST_COL, "Where to look", fmts.chrome("header_left"))
    r += 1

    items = [
        ("Bookings with an action or conflict",
         'COUNTIF([[Bookings.alert]],"Action*")+'
         'COUNTIF([[Bookings.alert]],"Overdue*")+'
         'COUNTIF([[Bookings.alert]],"Conflict*")',
         "Bookings - Action needed column"),
        ("Visits to log or update",
         'COUNTIF([[Visit Log.alert]],"Action*")+'
         'COUNTIF([[Visit Log.alert]],"Overdue*")+'
         'COUNTIF([[Visit Log.alert]],"Missed*")',
         "Visit Log - Action needed column"),
        ("Invoices still in draft", 'COUNTIF([[Invoices.status]],"Draft")',
         "Invoices - Invoice status"),
        ("Invoices overdue", 'COUNTIF([[Invoices.pay_status]],"Overdue*")',
         "Invoices - Payment status"),
        ("Pets with vaccinations expired",
         'COUNTIF([[Pets.vacc_status]],"Expired")', "Pets - Vaccination status"),
        ("Staff certificates expired or missing",
         'COUNTIF([[Staff.cert_status]],"Expired")+'
         'COUNTIF([[Staff.cert_status]],"No certificate*")',
         "Staff - Certificate status"),
        ("Inventory to reorder",
         'COUNTIF([[Inventory.stock_status]],"Reorder*")+'
         'COUNTIF([[Inventory.stock_status]],"Out of stock")',
         "Inventory - Stock level"),
        ("Overdue reminders", 'COUNTIF([[Reminders.alert]],"Overdue")',
         "Reminders - Action needed"),
        ("Expenses awaiting approval",
         'COUNTIF([[Expenses.approval]],"Pending")',
         "Expenses - Approval"),
    ]
    label_fmt = fmts.chrome("label")
    count_fmt = fmts.calc("int", align="center", bold=True)
    where_fmt = fmts.chrome("note")
    for label, formula, where in items:
        s.row_height(r, 18)
        s.merge(r, 0, 5, label, label_fmt)
        s.ws.merge_range(r, 6, r, 7, "", count_fmt)
        s.ws.write_formula(r, 6, s.reg.render(formula), count_fmt)
        s.merge(r, 8, LAST_COL, where, where_fmt)
        r += 1

    # ---- chart ------------------------------------------------------------
    r += 1
    r = s.section(r, "Twelve months at a glance", LAST_COL)
    chart = book.add_chart({"type": "column"})
    chart.add_series({
        "name": "Received",
        "categories": "=" + reg.rng("Calc", "label"),
        "values": "=" + reg.rng("Calc", "received"),
        "fill": {"color": Palette.primary_mid},
    })
    chart.add_series({
        "name": "Costs",
        "categories": "=" + reg.rng("Calc", "label"),
        "values": "=" + reg.rng("Calc", "costs"),
        "fill": {"color": Palette.accent},
    })
    chart.set_title({"name": "Money in and out",
                     "name_font": {"size": 12, "bold": True}})
    chart.set_legend({"position": "bottom"})
    chart.set_y_axis({"num_format": cfg.money_format_0,
                      "major_gridlines": {"visible": True,
                                          "line": {"color": "#E3E9EC"}}})
    chart.set_size({"width": 1000, "height": 320})
    s.ws.insert_chart(r, 0, chart, {"x_offset": 4, "y_offset": 6})

    s.ws.set_row(0, 34)
    s.finish(gridlines=False, fit_width=True)
    return s
