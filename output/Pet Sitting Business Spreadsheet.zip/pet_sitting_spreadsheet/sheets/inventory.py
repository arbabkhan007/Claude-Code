"""`Inventory` - supplies, stock levels, reorder points and expiry dates."""

from __future__ import annotations

from ..config import Config, Palette
from ..layout import Col, SheetSpec
from ..sample_data import get as sample
from ..writer import date_check, list_from, number_check
from .common import alert_cf, blank, id_col, status_cf

NAME = "Inventory"


def spec(cfg: Config) -> SheetSpec:
    columns = [
        id_col("item", '"IV-"', header="Item ID", width=10),
        Col("item", "Item", 26, "text"),
        Col("category", "Category", 18, "text",
            validate=list_from("InventoryCategoryList")),
        Col("supplier", "Supplier", 18, "text"),
        Col("unit", "Unit", 9, "text"),
        Col("unit_cost", "Cost per unit", 11, "money",
            validate=number_check(0, 100000)),
        Col("qty", "In stock", 9, "number1",
            validate=number_check(0, 1000000)),
        Col("min_qty", "Minimum level", 10, "number1",
            validate=number_check(0, 1000000)),
        Col("reorder_qty", "Reorder quantity", 11, "number1",
            validate=number_check(0, 1000000)),
        Col("stock_value", "Stock value", 12, "money",
            formula=blank("item", 'ROUND({qty}{r}*{unit_cost}{r},2)')),
        Col("stock_status", "Stock level", 14, "status",
            formula=blank("item",
                          'IF({qty}{r}<=0,"Out of stock",'
                          'IF({qty}{r}<={min_qty}{r},"Reorder now","In stock"))'),
            cf=[{"type": "text", "criteria": "containing",
                 "value": "Out of stock", "fmt": "bold_bad"},
                {"type": "text", "criteria": "containing",
                 "value": "Reorder", "fmt": "warn"},
                {"type": "text", "criteria": "containing",
                 "value": "In stock", "fmt": "good"}]),
        Col("last_purchase", "Last bought", 12, "date", validate=date_check()),
        Col("expiry", "Use by", 12, "date", validate=date_check()),
        Col("expiry_status", "Expiry", 13, "status",
            formula=blank("expiry",
                          'IF({expiry}{r}<TODAY(),"Expired",'
                          'IF({expiry}{r}-TODAY()<=ExpiryAlertDays,'
                          '"Due soon","OK"))'),
            cf=alert_cf()),
        Col("used_month", "Used per month", 11, "number1",
            validate=number_check(0, 1000000)),
        Col("notes", "Notes", 26, "wrap"),
        Col("alert", "Action needed", 24, "status",
            formula=blank(
                "item",
                'IF({expiry_status}{r}="Expired","Action - remove expired stock",'
                'IF({stock_status}{r}="Out of stock","Action - order now",'
                'IF({stock_status}{r}="Reorder now","Action - reorder",'
                '"OK")))'),
            cf=alert_cf()),
    ]

    return SheetSpec(
        name=NAME,
        title="Inventory & Supplies",
        subtitle="Track consumables and kit. Stock values, reorder alerts and "
                 "expiry warnings are calculated for you.",
        columns=columns,
        rows=cfg.row_count(NAME),
        tab_color=Palette.grey_text,
        freeze_cols=2,
        samples=sample(cfg).inventory,
        help_text="Update 'In stock' after every shop. Anything at or below the "
                  "minimum level is flagged for reorder.",
    )
