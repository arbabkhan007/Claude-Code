"""`Help` - how the workbook works, protection, data safety and common questions."""

from __future__ import annotations

from ..config import Config, Palette
from ..writer import SheetWriter

SHEET = "Help"
LAST_COL = 4

SECTIONS = [
    ("How the workbook fits together", [
        "Work from left to right on each register: fill in the cream columns "
        "and the grey columns follow automatically.",
        "Clients feed Pets. Pets and Services feed Bookings. Bookings feed the "
        "Visit Log and Invoices. Invoices and Payments feed balances. Expenses "
        "and Mileage feed the Calc engine behind the Dashboard and Reports.",
        "Use the drop downs wherever you see them. They read from the Lists "
        "tab and from the names you type on other tabs, so spelling stays "
        "consistent.",
    ]),
    ("Adding a new client", [
        "1. Clients - type the name, contact details, access and contract "
        "status. Use the same spelling every time.",
        "2. Pets - choose the owner from the drop down, then add the pet.",
        "3. Bookings - pick the client and pet, the service and the date. "
        "The price calculates automatically.",
    ]),
    ("Invoices and payments", [
        "Invoices: pick the client, then either link a Booking ID (the amount "
        "comes from the booking) or enter Qty and Rate for custom work.",
        "Payments: choose the invoice and enter the amount. The invoice "
        "balance and payment status update on their own.",
        "Invoice status is yours to set (Draft, Sent, Cancelled). Payment "
        "status is calculated.",
    ]),
    ("Colours and alerts", [
        "Cream cells are inputs. Grey cells are formulas. Green, amber and red "
        "shading in the Alert or Status columns shows what needs attention.",
        "The Action needed column tells you the next step for each record.",
    ]),
    ("Protection and password", [
        "Every sheet is protected so formulas cannot be overwritten by "
        "accident. Cream cells remain fully editable.",
        "To change a formula, use Review > Unprotect Sheet and enter the "
        "password shown on the Start Here tab. Protect the sheet again "
        "afterwards.",
        "Filtering is allowed on every register. Sorting is turned off so rows "
        "cannot drift out of step with their IDs.",
    ]),
    ("Keeping your data safe", [
        "Save a dated copy at the end of every month (File > Save As, add the "
        "date to the file name).",
        "Keep client addresses, key codes and vet details private. Store full "
        "alarm codes in a password manager, not in the workbook.",
        "Follow your local privacy rules when you share client information "
        "with vets, insurers or staff.",
    ]),
    ("Troubleshooting", [
        "A drop down is missing an option: add it on the Lists tab in the "
        "matching column. It appears everywhere straight away.",
        "A price looks wrong: check the Services tab for the rate, the "
        "holiday and weekend percentages, and the Settings tab for the "
        "additional pet fee and travel rules.",
        "The Schedule check says Conflict: the same carer is booked twice in "
        "an overlapping time. Move one of the bookings.",
        "A cell shows #VALUE! or a blank where you expected a number: check "
        "that dates and amounts are typed as numbers, not as text.",
    ]),
    ("Good to know", [
        "The workbook uses only functions from Excel 2010 onwards, so it "
        "works in Excel, LibreOffice and Google Sheets with minimal changes.",
        "Example records are included so you can see how everything fits "
        "together. Clear them out by selecting the cream cells on each tab and "
        "pressing Delete - formulas stay in place.",
        "Prepared by {author}. Version {version}.",
    ]),
]


def build(book, fmts, cfg: Config, reg) -> SheetWriter:
    s = SheetWriter(book, fmts, cfg, reg, SHEET, tab_color=Palette.grey_text,
                    landscape=False)
    s.set_col(0, 0, 3)
    s.set_col(1, LAST_COL, 18)
    s.banner("Help & Guidance",
             "Read this once and the rest of the workbook will make sense.",
             LAST_COL)

    r = 3
    for heading, paragraphs in SECTIONS:
        r = s.section(r, heading, LAST_COL, first_col=1)
        for text in paragraphs:
            text = text.replace("{author}", cfg.author).replace(
                "{version}", cfg.version)
            lines = max(1, len(text) // 105 + 1)
            r = s.note(r, text, LAST_COL, first_col=1,
                       height=15 * lines + 6, boxed=False)
        r += 1

    s.finish(gridlines=False)
    return s
